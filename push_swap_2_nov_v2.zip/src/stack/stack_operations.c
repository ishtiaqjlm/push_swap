/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_operations.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:29:22 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 15:37:50 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "stack.h"
#include "stack_operations.h"

int	stack_swap(t_array_stack *stack)
{
	int	x;

	if ((stack->top == (size_t)-1)
		|| (stack->top == 0))
		return (-1);
	x = stack->data[stack->top];
	stack->data[stack->top] = stack->data[stack->top -1];
	stack->data[stack->top - 1] = x;
	return (0);
}

// shift UP all elements of a stack by one.
// the FIRST element becomes the LAST one.
int	stack_rotate(t_array_stack *stack)
{
	t_stack_element	e;
	size_t			i;

	if (stack->top == (size_t)-1 || stack->top == 0)
		return (0);
	e = stack->data[stack->top];
	i = stack->top;
	while (i > 0)
	{
		stack->data[i] = stack->data[i - 1];
		i--;
	}
	stack->data[0] = e;
	return (0);
}

// shift DOWN all elements of a stack by one
// the LAST element becomes the FIRST one
int	stack_rrotate(t_array_stack *stack)
{
	t_stack_element	e;
	size_t			i;

	if ((stack->top == (size_t)-1)
		|| (stack->top == 0))
		return (0);
	e = stack->data[0];
	i = 0;
	while (i != stack->top)
	{
		stack->data[i] = stack->data[i + 1];
		i++;
	}
	stack->data[stack->top] = e;
	return (0);
}
