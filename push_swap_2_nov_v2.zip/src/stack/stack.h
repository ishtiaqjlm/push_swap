/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:29:18 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 15:35:07 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STACK_H
# define STACK_H
# include <stddef.h>

typedef struct stack
{
	char	*name;
	size_t	capacity;
	size_t	top;
	int		*data;
}	t_array_stack;

typedef int	t_stack_element;
typedef int	t_stack_rv;

int	stack_initialize(t_array_stack **pstack, char *name);
int	stack_finalize(t_array_stack **pstack);
int	stack_push(t_array_stack *stack, t_stack_element *e);
int	stack_pop(t_array_stack *stack, t_stack_element *e);
int	stack_swap(t_array_stack *stack);
int	stack_rotate(t_array_stack *stack);
int	stack_rrotate(t_array_stack *stack);
int	stack_print(t_array_stack *stack);
int	stack_is_sorted(t_array_stack *stack);
#endif // STACK_H
