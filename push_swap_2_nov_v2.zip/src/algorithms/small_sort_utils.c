/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   small_sort_utils.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/29 14:58:11 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/11/02 18:47:12 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <operations.h>
#include <stack.h>
#include <algorithms.h>
#include <libft.h>
#include <unistd.h>

void	sort_two(t_two_towers_ctx *ctx)
{
	int	first;
	int	second;

	first = ctx->stack_a->data[ctx->stack_a->top];
	second = ctx->stack_a->data[ctx->stack_a->top - 1];
	if (first > second)
		swap_a(ctx);
}

void	sort_three(t_two_towers_ctx *ctx)
{
	int	first;
	int	second;
	int	third;

	first = ctx->stack_a->data[ctx->stack_a->top];
	second = ctx->stack_a->data[ctx->stack_a->top - 1];
	third = ctx->stack_a->data[ctx->stack_a->top - 2];
	if (first > second && second < third && first < third)
		swap_a(ctx);
	else if (first > second && second > third)
	{
		swap_a(ctx);
		reverse_rotate_a(ctx);
	}
	else if (first > second && second < third && first > third)
		rotate_a(ctx);
	else if (first < second && second > third && first < third)
	{
		swap_a(ctx);
		rotate_a(ctx);
	}
	else if (first < second && second > third && first > third)
		reverse_rotate_a(ctx);
}

int	is_sorted(t_array_stack *stack)
{
	size_t	i;

	if (stack->top == (size_t)-1)
		return (1);
	i = stack->top;
	while (i > 0)
	{
		if (stack->data[i] > stack->data[i - 1])
			return (0);
		i--;
	}
	return (1);
}
