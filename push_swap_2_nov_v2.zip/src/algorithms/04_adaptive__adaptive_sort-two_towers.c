/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   04_adaptive__adaptive_sort-two_towers.c            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:27:10 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 14:51:14 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <two_towers.h>
#include <algorithms.h>

void	two_towers_adaptive_sort(t_two_towers_ctx *ctx)
{
	double	disorder;
	size_t	n;

	if (ctx->stack_a->top == (size_t)-1)
		return ;
	n = ctx->stack_a->top + 1;
	disorder = compute_disorder(ctx->stack_a->data, n);
	if (disorder == 0.0)
		return ;
	if (disorder < 0.2)
		sort_simple(ctx);
	else if (disorder < 0.5)
		sort_medium(ctx);
	else
		two_towers_radix_sort(ctx);
}
