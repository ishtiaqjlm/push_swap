/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   disorder.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/29 16:49:32 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/11/02 14:58:36 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <algorithms.h>

static size_t	count_inversions(int *v, size_t n)
{
	size_t	i;
	size_t	j;
	size_t	mistakes;

	mistakes = 0;
	i = 0;
	while (i < n - 1)
	{
		j = i + 1;
		while (j < n)
		{
			if (v[i] > v[j])
				mistakes++;
			j++;
		}
		i++;
	}
	return (mistakes);
}

double	compute_disorder(int *v, size_t n)
{
	size_t	total_pairs;
	size_t	mistakes;

	total_pairs = n * (n - 1) / 2;
	if (total_pairs == 0)
		return (0.0);
	mistakes = count_inversions(v, n);
	return ((double)mistakes / (double)total_pairs);
}
