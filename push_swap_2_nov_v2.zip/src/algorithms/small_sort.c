/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   small_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/20 15:22:00 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/10/30 14:23:08 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <two_towers.h>
#include <operations.h>
#include <stack.h>
#include <algorithms.h>

static size_t	find_min_position(t_array_stack *stack)
{
	size_t	i;
	size_t	min_pos;

	i = stack->top;
	min_pos = i;
	while (i > 0)
	{
		i--;
		if (stack->data[i] < stack->data[min_pos])
			min_pos = i;
	}
	return (min_pos);
}

static void	rotate_min_to_top(t_two_towers_ctx *ctx, size_t min_pos)
{
	size_t	forward;
	size_t	reverse;
	size_t	top;

	top = ctx->stack_a->top;
	forward = top - min_pos;
	reverse = min_pos + 1;
	if (forward <= reverse)
	{
		while (forward-- > 0)
			rotate_a(ctx);
	}
	else
	{
		while (reverse-- > 0)
			reverse_rotate_a(ctx);
	}
}

void	sort_simple_general(t_two_towers_ctx *ctx)
{
	size_t	min_pos;

	if (is_sorted(ctx->stack_a))
		return ;
	while (ctx->stack_a->top != (size_t)-1)
	{
		min_pos = find_min_position(ctx->stack_a);
		rotate_min_to_top(ctx, min_pos);
		push_b(ctx);
	}
	while (ctx->stack_b->top != (size_t)-1)
		push_a(ctx);
}
