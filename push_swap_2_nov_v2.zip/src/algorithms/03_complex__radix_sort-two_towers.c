/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   03_complex__radix_sort-two_towers.c                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:26:55 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 18:51:26 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// radixsort

// https://en.wikipedia.org/wiki/Radix_sort
// https://www.w3schools.com/dsa/dsa_algo_radixsort.php

#include <stdlib.h>		// malloc
#include <two_towers.h>
#include <algorithms.h>
#include <unistd.h>
#include <libft.h>
// if the quantity of numbers is less than 3,
//
// use a direct approach to sorting
//	. two numbers
//	. three numbers
/*
static void	check_number_quantity_is_enough(void)
{
}
*/

static size_t	get_number_of_rounds(size_t nelements)
{
	size_t	nrounds;
	size_t	m;

	nrounds = 0;
	m = nelements - 1;
	while (m != 0)
	{
		m = m >> 1;
		nrounds++;
	}
	return (nrounds);
}

static void	analyze_element(t_two_towers_ctx *ctx,
	size_t *xlat_table,
	size_t xlat_table_length,
	size_t i)
{
	size_t	x;

	x = ctx->stack_a->data[ctx->stack_a->top];
	x = xlat_from_zsubset_to_nonnegative_integers(
			x, xlat_table, xlat_table_length);
	if (((x >> i) & 1) == 0)
		push_b(ctx);
	else
		rotate_a(ctx);
}

static void	consolidate_stacks(t_two_towers_ctx *ctx)
{
	while (ctx->stack_b->top != (size_t)(-1))
		push_a(ctx);
}

static void	radix_sort(
	t_two_towers_ctx *ctx,
	size_t *xlat_table,
	size_t xlat_table_length)
{
	size_t	ncolumns;
	size_t	nelements;
	size_t	i;
	size_t	j;

	nelements = ctx->stack_a->top + 1;
	ncolumns = get_number_of_rounds(nelements);
	i = 0;
	while (i != ncolumns)
	{
		j = 0;
		while (j != nelements)
		{
			analyze_element(ctx, xlat_table, xlat_table_length, i);
			j++;
		}
		consolidate_stacks(ctx);
		i++;
	}
}

// TODO
//	check_number_quantity_is_enough();
// XXX malloc failure
void	two_towers_radix_sort(t_two_towers_ctx *ctx)
{
	size_t	*xlat_table;
	size_t	xlat_table_length;
	size_t	n;
	size_t	m;

	if (is_sorted(ctx->stack_a))
		return ;
	n = ctx->stack_a->top + 1;
	xlat_table_length = n;
	m = sizeof(size_t) * xlat_table_length;
	xlat_table = malloc(m);
	if (xlat_table == NULL)
	{
		return ;
	}
	init_xlat_from_zsubset_to_nonnegative_integers(
		ctx, xlat_table, xlat_table_length);
	radix_sort(ctx, xlat_table, xlat_table_length);
	free(xlat_table);
}
