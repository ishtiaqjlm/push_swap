/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   medium_reconstruct.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/27 12:12:18 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/11/02 15:08:12 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stack.h>
#include <two_towers.h>
#include <algorithms.h>

static size_t	find_max_position(t_array_stack *stack)
{
	size_t	i;
	size_t	max_pos;

	max_pos = stack->top;
	i = stack->top;
	while (i > 0)
	{
		i--;
		if (stack->data[i] > stack->data[max_pos])
			max_pos = i;
	}
	return (max_pos);
}

static void	bring_max_to_top(t_two_towers_ctx *ctx, size_t max_pos)
{
	size_t	forward;
	size_t	reverse;

	forward = ctx->stack_b->top - max_pos;
	reverse = ctx->stack_b->top - max_pos + 1;
	if (forward <= reverse)
	{
		while (forward > 0)
		{
			rotate_b(ctx);
			forward--;
		}
	}
	else
	{
		while (reverse > 0)
		{
			reverse_rotate_b(ctx);
			reverse--;
		}
	}
}

void	reconstruct_stack(t_two_towers_ctx *ctx)
{
	size_t	max_pos;

	while (ctx->stack_b->top != (size_t)-1)
	{
		max_pos = find_max_position(ctx->stack_b);
		bring_max_to_top(ctx, max_pos);
		push_a(ctx);
	}
}
