/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_operation_rotate.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:13 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 15:21:20 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <two_towers.h>
#include <operations.h>

void	rotate_a(t_two_towers_ctx *ctx)
{
	if (ctx->stack_a->top != (size_t)-1
		&& ctx->stack_a->top > 0)
	{
		stack_rotate(ctx->stack_a);
		ctx->statistics[OPERATIONS_ROTATE_A - 1]++;
		operation_output("ra");
	}
}

void	rotate_b(t_two_towers_ctx *ctx)
{
	if (ctx->stack_b->top != (size_t)-1
		&& ctx->stack_b->top > 0)
	{
		stack_rotate(ctx->stack_b);
		ctx->statistics[OPERATIONS_ROTATE_B - 1]++;
		operation_output("rb");
	}
}

void	rotate_both(t_two_towers_ctx *ctx)
{
	int	a;
	int	b;

	a = (ctx->stack_a->top != (size_t)-1
			&& ctx->stack_a->top > 0);
	b = (ctx->stack_b->top != (size_t)-1
			&& ctx->stack_b->top > 0);
	if (a || b)
	{
		if (a)
			stack_rotate(ctx->stack_a);
		if (b)
			stack_rotate(ctx->stack_b);
		ctx->statistics[OPERATIONS_ROTATE_BOTH - 1]++;
		operation_output("rr");
	}
}
