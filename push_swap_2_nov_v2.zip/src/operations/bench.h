/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bench.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/02 15:28:10 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 15:28:34 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef BENCH_H
# define BENCH_H
/* benchmark */
void	run_bench(t_two_towers_ctx *ctx, t_config *config, double disorder);
void	print_detail_operation(t_two_towers_ctx *ctx);
#endif
