/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_operation_swap.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:25 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 15:27:13 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <operations.h>
#include <two_towers.h>

void	swap_a(t_two_towers_ctx *ctx)
{
	if (stack_swap(ctx->stack_a) == 0)
	{
		ctx->statistics[OPERATIONS_SWAP_A - 1]++;
		operation_output("sa");
	}
}

void	swap_b(t_two_towers_ctx *ctx)
{
	if (stack_swap(ctx->stack_b) == 0)
	{
		ctx->statistics[OPERATIONS_SWAP_B - 1]++;
		operation_output("sb");
	}
}

void	swap_ab(t_two_towers_ctx *ctx)
{
	int	a;
	int	b;

	a = stack_swap(ctx->stack_a);
	b = stack_swap(ctx->stack_b);
	if (a == 0 || b == 0)
	{
		ctx->statistics[OPERATIONS_SWAP_BOTH - 1]++;
		operation_output("ss");
	}
}
