/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_operation_push.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:04 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 15:17:34 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <two_towers.h>
#include <libft.h>
#include <operations.h>

void	push_a(t_two_towers_ctx *ctx)
{
	t_stack_element	e;

	if (ctx->stack_b->top == (size_t)-1)
		return ;
	if (stack_pop(ctx->stack_b, &e) == -1)
		return ;
	if (stack_push(ctx->stack_a, &e) == -1)
	{
		stack_push(ctx->stack_b, &e);
		return ;
	}
	ctx->statistics[OPERATIONS_PUSH_A - 1]++;
	operation_output("pa");
}

void	push_b(t_two_towers_ctx *ctx)
{
	t_stack_element	e;

	if (ctx->stack_a->top == (size_t)-1)
		return ;
	if (stack_pop(ctx->stack_a, &e) == -1)
		return ;
	if (stack_push(ctx->stack_b, &e) == -1)
	{
		stack_push(ctx->stack_a, &e);
		return ;
	}
	ctx->statistics[OPERATIONS_PUSH_B - 1]++;
	operation_output("pb");
}
