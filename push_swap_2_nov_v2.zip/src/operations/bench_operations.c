/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bench_operations.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/02 14:05:07 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/11/02 15:12:30 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <push_swap.h>
#include <algorithms.h>
#include <bench.h>
#include <libft.h>
#include <operations.h>

static void	print_first_operations(t_two_towers_ctx *ctx)
{
	write(2, "[bench] sa: ", 12);
	ft_putnbr_fd(ctx->statistics[OPERATIONS_SWAP_A - 1], 2);
	write(2, "  sb: ", 6);
	ft_putnbr_fd(ctx->statistics[OPERATIONS_SWAP_B - 1], 2);
	write(2, "  ss: ", 6);
	ft_putnbr_fd(ctx->statistics[OPERATIONS_SWAP_BOTH - 1], 2);
	write(2, "  pa: ", 6);
	ft_putnbr_fd(ctx->statistics[OPERATIONS_PUSH_A - 1], 2);
	write(2, "  pb: ", 6);
	ft_putnbr_fd(ctx->statistics[OPERATIONS_PUSH_B - 1], 2);
	write(2, "\n", 1);
}

static void	print_second_operations(t_two_towers_ctx *ctx)
{
	write(2, "[bench] ra: ", 12);
	ft_putnbr_fd(ctx->statistics[OPERATIONS_ROTATE_A - 1], 2);
	write(2, "  rb: ", 6);
	ft_putnbr_fd(ctx->statistics[OPERATIONS_ROTATE_B - 1], 2);
	write(2, "  rr: ", 6);
	ft_putnbr_fd(ctx->statistics[OPERATIONS_ROTATE_BOTH - 1], 2);
	write(2, "  rra: ", 7);
	ft_putnbr_fd(ctx->statistics[OPERATIONS_RROTATE_A - 1], 2);
	write(2, "  rrb: ", 7);
	ft_putnbr_fd(ctx->statistics[OPERATIONS_RROTATE_B - 1], 2);
	write(2, "  rrr: ", 7);
	ft_putnbr_fd(ctx->statistics[OPERATIONS_RROTATE_BOTH - 1], 2);
	write(2, "\n", 1);
}

void	print_detail_operation(t_two_towers_ctx *ctx)
{
	print_first_operations(ctx);
	print_second_operations(ctx);
}
