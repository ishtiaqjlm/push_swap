/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operation_output.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/15 02:04:16 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/11/02 15:13:59 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	operation_output(const char *operation)
{
	while (*operation)
	{
		write(1, operation, 1);
		operation++;
	}
	write(1, "\n", 1);
}
