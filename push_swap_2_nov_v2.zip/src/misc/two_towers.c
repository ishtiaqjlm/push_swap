/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:31:53 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 16:54:26 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

#include <stack.h>
#include <two_towers.h>
#include <libft.h>					// stubs to ft_* functions

int	two_towers_initialize(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;
	t_array_stack		*stack_a;
	t_array_stack		*stack_b;

	*pctx = NULL;
	ctx = malloc(sizeof(t_two_towers_ctx));
	if (ctx == NULL)
		return (-1);
	if (stack_initialize(&stack_a, "a") == -1)
	{
		free(ctx);
		return (-1);
	}
	if (stack_initialize(&stack_b, "b") == -1)
	{
		stack_finalize(&stack_a);
		free(ctx);
		return (-1);
	}
	ctx->stack_a = stack_a;
	ctx->stack_b = stack_b;
	ft_memset(ctx->statistics, 0, sizeof(ctx->statistics));
	*pctx = ctx;
	return (0);
}

int	two_towers_finalize(t_two_towers_ctx	**pctx)
{
	t_two_towers_ctx	*ctx;
	t_array_stack		*stack_a;
	t_array_stack		*stack_b;

	ctx = *pctx;
	stack_a = ctx->stack_a;
	stack_finalize(&stack_a);
	stack_b = ctx->stack_b;
	stack_finalize(&stack_b);
	free(ctx);
	*pctx = NULL;
	return (0);
}

int	two_towers_populate(t_two_towers_ctx **pctx, int *numbers, size_t nnumbers)
{
	size_t				i;
	t_array_stack		*stack_a;
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	stack_a = ctx->stack_a;
	ctx = *pctx;
	stack_a = ctx->stack_a;
	i = nnumbers;
	while (i > 0)
	{
		i--;
		if (stack_push(stack_a, &numbers[i]) == -1)
			return (-1);
	}
	return (0);
}
