## Parsing and Validation

### Implemented functions

* `ft_strcmp()` — compares two strings, used to identify command-line options.
* `parse_args()` — identifies strategy options and `--bench`, then returns the index of the first stack argument.
* `parse_number()` — converts a string to an integer and rejects invalid or out-of-range values.
* `duplicate_check()` — detects duplicate values in a stack.
* `is_sorted()` — checks whether the stack is already sorted in ascending order.

### main.c example

``` code
int	main(int argc, char **argv)
{
	//test code for parsing arguments and numbers
    t_config	config;
	int			start;
	int			number;
	int			i;

	if (argc == 1)
		return (0);
	start = parse_args(argc, argv, &config);
	i = start;
	while (i < argc)
	{
		if (parse_number(argv[i], &number) == 1)
		{
			write(2, "Error\n", 6);
			return (1);
		}
		write(1, "valid\n", 6);
		i++;
	}
	return (0);
}
```	

### Command-line options

The program supports the following strategy selectors:

* `--simple`
* `--medium`
* `--complex`
* `--adaptive` (default)
* `--bench` (benchmark mode)

Example commands for the integrated program:

```bash
./push_swap --simple 3 2 1
./push_swap --medium 3 2 1
./push_swap --complex 3 2 1
./push_swap --adaptive 3 2 1
./push_swap --bench 3 2 1
```

These commands require the complete program and all relevant strategy implementations to be integrated.

### Parsing test cases

**Valid integers**

* `42`
* `-42`
* `+42`
* `2147483647`
* `-2147483648`

**Invalid integers**

* `abc`
* `12abc`
* `2147483648`
* `-2147483649`
* An empty string or a sign without digits

**Duplicate values**

* `10 20 30` — valid
* `10 20 10` — invalid
* `-5 10 -5` — invalid

**Sorted stack**

* `1 2 3` — already sorted
* `3 2 1` — not sorted

### Integration note

The parsing functions and prototypes are provided for integration with the shared `main.c`. `parse_args()` returns the index of the first stack argument; the main program should use this index when building the stack.

The test commands above are examples for the complete integrated program, not standalone tests for the parsing functions.
