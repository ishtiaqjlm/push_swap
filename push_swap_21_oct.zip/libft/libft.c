/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 15:53:50 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 15:58:49 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libft.h>

#include <string.h>
#include <stdio.h>

void	*ft_memset(void *s, int c, size_t n)
{
	unsigned int	i;
	char			*t;

	t = s;
	i = 0;
	while (i < n)
	{
		t[i] = c;
		i += 1;
	}
	return (s);
}

// XXX ft_printf() "should not be included"
int	ft_printf(const char *format, ...)
{
	va_list	ap;

	va_start(ap, format);
	return (vprintf(format, ap));
}
