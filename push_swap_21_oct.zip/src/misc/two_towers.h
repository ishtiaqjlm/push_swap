/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:36:30 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/21 16:27:51 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TWO_TOWERS_H
# define TWO_TOWERS_H
# include "stack.h"
# include <stddef.h>

typedef struct two_towers_ctx
{
	t_array_stack	*stack_a;
	t_array_stack	*stack_b;
	size_t	statistics[0xb];
}	t_two_towers_ctx;

// 0x1. sa
void	swap_a(t_two_towers_ctx *ctx);

// 0x2. sb
void	swap_b(t_two_towers_ctx *ctx);

// 0x3. ss
void	swap_ab(t_two_towers_ctx *ctx);

// 0x4. pa
void	push_a(t_two_towers_ctx *ctx);

// 0x5. pb
void	push_b(t_two_towers_ctx *ctx);

// 0x6. ra
void	rotate_a(t_two_towers_ctx *ctx);

// 0x7. rb
void	rotate_b(t_two_towers_ctx *ctx);

// 0x8. rr
void	rotate_both(t_two_towers_ctx *ctx);

// 0x9. rra
void	reverse_rotate_a(t_two_towers_ctx *ctx);

// 0xa. rrb
void	reverse_rotate_b(t_two_towers_ctx *ctx);

// 0xb. rrr
void	reverse_rotate_both(t_two_towers_ctx *ctx);

//t_two_towers_status
int		two_towers_initialize(t_two_towers_ctx **pctx);
int		two_towers_finalize(t_two_towers_ctx **pctx);
int	two_towers_populate(t_two_towers_ctx **pctx, int *numbers, size_t nnumbers);
int		two_towers_status(t_two_towers_ctx **pctx);
int		two_towers_statistics(t_two_towers_ctx **pctx);

void	sort_simple(t_two_towers_ctx *ctx);
void	sort_medium(t_two_towers_ctx *ctx);
void	sort_complex(t_two_towers_ctx *ctx);
void	sort_adaptive(t_two_towers_ctx *ctx);

#endif // TWO_TOWERS_H
