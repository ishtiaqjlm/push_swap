/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_algorithms.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:31:49 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/21 17:53:33 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <two_towers.h>
#include <libft.h>
#include <algorithms.h>
#include <adapted_sort.h>

void	sort_simple(t_two_towers_ctx *ctx)
{
	size_t	n;

	if (ctx->stack_a->top == (size_t)-1)
		return ;
	n = ctx->stack_a->top + 1;
	if (n <= 1)
		return ;
	else if (n == 2)
		sort_two(ctx);
	else if (n == 3)
		sort_three(ctx);
	else
		sort_simple_general(ctx);
}

void	sort_medium(t_two_towers_ctx *ctx)
{
	/*size_t	n;
	t_array_stack	*stack;

	stack = ctx->stack_a;
	n = ctx->stack_a->top + 1;
	adapted_shell_sort(stack, n);*/
	sort_simple(ctx);
}

void	sort_complex(t_two_towers_ctx *ctx)
{
	/*size_t	n;
	t_array_stack	*stack;

	stack = ctx->stack_a;
	n = ctx->stack_a->top + 1;
	adapted_heap_sort(stack, n);*/
	sort_simple(ctx);
}

void	sort_adaptive(t_two_towers_ctx *ctx)
{
	/*size_t	n;
	t_array_stack	*stack;

	stack = ctx->stack_a;
	n = ctx->stack_a->top + 1;
	adapted_adaptive_sort(stack, n);*/
	sort_simple(ctx);
}
