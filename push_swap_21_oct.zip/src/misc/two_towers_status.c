/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_status.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:32:04 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 14:45:02 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <two_towers.h>
#include <libft.h>
#include <operations.h>

static void	print_header(size_t top_a, size_t top_b)
{
	if (top_a == (size_t)-1)
		ft_printf("\ttop_a: N/A\n");
	else
		ft_printf("\ttop_a: %zu\n", top_a);
	if (top_b == (size_t)-1)
		ft_printf("\ttop_b: N/A\n");
	else
		ft_printf("\ttop_b: %zu\n", top_b);
}

// prelude
/*
	if ((top_a == (size_t)-1)
		&& (top_b == (size_t)-1))
	{
	}
*/

static size_t	select_top(size_t top_a, size_t top_b)
{
	size_t	top;

	if (top_a != (size_t)(-1))
	{
		if (top_b == (size_t)(-1))
			top = top_a;
		else if (top_a >= top_b)
			top = top_a;
		else
			top = top_b;
	}
	else
	{
		if (top_a == (size_t)(-1))
			top = top_b;
		else if (top_b >= top_a)
			top = top_b;
		else
			top = top_a;
	}
	if (top == (size_t)(-1))
		ft_printf("\t  top: N/A\n");
	else
		ft_printf("\t  top: %zu\n", top);
	return (top);
}

static void	print_body(size_t top, size_t top_a, size_t top_b,\
		t_two_towers_ctx *ctx)
{
	size_t	i;

	i = top;
	while (i != (size_t)(-1))
	{
		ft_printf("\t");
		if (top_a == (size_t)(-1))
			ft_printf("\t    ");
		else if (i <= top_a)
			ft_printf("%4d", ctx->stack_a->data[i]);
		else
			ft_printf("\t    ");
		if (top_b == (size_t)(-1))
			ft_printf("\t    ");
		else if (i <= top_b)
			ft_printf("\t%4d", ctx->stack_b->data[i]);
		else
			ft_printf("\t    ");
		ft_printf("\n");
		i--;
	}
}

int	two_towers_status(t_two_towers_ctx	**pctx)
{
	t_two_towers_ctx	*ctx;
	size_t				top_a;
	size_t				top_b;
	size_t				top;

	ctx = *pctx;
	ft_printf("<status>\n");
	top_a = ctx->stack_a->top;
	top_b = ctx->stack_b->top;
	print_header(top_a, top_b);
	top = select_top(top_a, top_b);
	ft_printf("\t======\n");
	print_body(top, top_a, top_b, ctx);
	ft_printf("\t----\t----\n");
	ft_printf("\ta   \tb\n");
	ft_printf("</status>\n");
	return (0);
}

int	two_towers_statistics(t_two_towers_ctx	**pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	ft_printf("<statistics>\n");
	ft_printf("\t sa: %5d\n", ctx->statistics[OPERATIONS_SWAP_A - 1]);
	ft_printf("\t sb: %5d\n", ctx->statistics[OPERATIONS_SWAP_B - 1]);
	ft_printf("\t ss: %5d\n", ctx->statistics[OPERATIONS_SWAP_BOTH - 1]);
	ft_printf("\t pa: %5d\n", ctx->statistics[OPERATIONS_PUSH_A - 1]);
	ft_printf("\t pb: %5d\n", ctx->statistics[OPERATIONS_PUSH_B - 1]);
	ft_printf("\t ra: %5d\n", ctx->statistics[OPERATIONS_ROTATE_A - 1]);
	ft_printf("\t rb: %5d\n", ctx->statistics[OPERATIONS_ROTATE_B - 1]);
	ft_printf("\t rr: %5d\n", ctx->statistics[OPERATIONS_ROTATE_BOTH - 1]);
	ft_printf("\trra: %5d\n", ctx->statistics[OPERATIONS_RROTATE_A - 1]);
	ft_printf("\trrb: %5d\n", ctx->statistics[OPERATIONS_RROTATE_B - 1]);
	ft_printf("\trrr: %5d\n", ctx->statistics[OPERATIONS_RROTATE_BOTH - 1]);
	ft_printf("</statistics>\n");
	return (0);
}
