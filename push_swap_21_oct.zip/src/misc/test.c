/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:31:45 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 15:43:31 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <two_towers.h>
//#include <adapted_sort.h>

void	test_two_towers_populate_simple_tests(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;
	int					numbers[10];
	size_t				nnumbers;

	ctx = *pctx;
	numbers[0] = 2;
	numbers[1] = 3;
	numbers[2] = 5;
	numbers[3] = 7;
	numbers[4] = 11;
	numbers[5] = 13;
	numbers[6] = 17;
	numbers[7] = 19;
	numbers[8] = 23;
	numbers[9] = 29;
	nnumbers = 10;
	printf("two_towers_status()...\n");
	two_towers_status(&ctx);
	printf("two_towers_populate()...\n");
	two_towers_populate(&ctx, numbers, nnumbers);
	printf("two_towers_status()...\n");
	two_towers_status(&ctx);
}

void	test_two_towers_populate_algorithm_tests(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;
	int					numbers[10];
	size_t				nnumbers;

	ctx = *pctx;
	numbers[0] = 3;
	numbers[1] = 11;
	numbers[2] = 29;
	numbers[3] = 7;
	numbers[4] = 2;
	numbers[5] = 5;
	numbers[6] = 17;numbers[0] = 3;
	numbers[1] = 11;
	numbers[2] = 29;
	numbers[3] = 7;
	numbers[4] = 2;
	numbers[5] = 5;
	numbers[6] = 17;
	numbers[7] = 19;
	numbers[8] = 23;
	numbers[9] = 13;
	numbers[7] = 19;
	numbers[8] = 23;
	numbers[9] = 13;
	nnumbers = 10;
	printf("two_towers_status()...\n");
	two_towers_status(&ctx);
	printf("two_towers_populate()...\n");
	two_towers_populate(&ctx, numbers, nnumbers);
	printf("two_towers_status()...\n");
	two_towers_status(&ctx);
}

void	test_two_towers_push_b(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	printf("pb\n");
	push_b(ctx);
	two_towers_status(&ctx);
}

void	test_two_towers_push_a(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	printf("pa\n");
	push_a(ctx);
	two_towers_status(&ctx);
}

void	test_two_towers_swap_b(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	printf("sb\n");
	swap_b(ctx);
	two_towers_status(&ctx);
}

void	test_two_towers_swap_a(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	printf("sa\n");
	swap_a(ctx);
	two_towers_status(&ctx);
}

void	test_two_towers_swap_ab(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	printf("ss\n");
	swap_ab(ctx);
	two_towers_status(&ctx);
}

void	test_two_towers_rotate_b(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	printf("rb\n");
	rotate_b(ctx);
	two_towers_status(&ctx);
}

void	test_two_towers_rotate_a(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	printf("ra\n");
	rotate_a(ctx);
	two_towers_status(&ctx);
}

void	test_two_towers_rotate_both(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	printf("rr\n");
	rotate_both(ctx);
	two_towers_status(&ctx);
}

void	test_two_towers_reverse_rotate_b(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	printf("rrb\n");
	reverse_rotate_b(ctx);
	two_towers_status(&ctx);
}

void	test_two_towers_reverse_rotate_a(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	printf("rra\n");
	reverse_rotate_a(ctx);
	two_towers_status(&ctx);
}

void	test_two_towers_reverse_rotate_both(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	printf("rrr\n");
	reverse_rotate_both(ctx);
	two_towers_status(&ctx);
}

void	simple_tests_1(t_two_towers_ctx	*ctx)
{
	if (1)
	{
		push_b(ctx);
		push_b(ctx);
		push_b(ctx);
		push_b(ctx);
		push_b(ctx);
		push_a(ctx);
		push_a(ctx);
		printf("two_towers_status()...\n");
		two_towers_status(&ctx);
		printf("*******************************************************\n");
	}
}

void	simple_tests_2(t_two_towers_ctx	*ctx)
{
	if (1)
	{
		test_two_towers_swap_b(&ctx);
		test_two_towers_swap_a(&ctx);
		test_two_towers_swap_ab(&ctx);
	}
	if (1)
	{
		test_two_towers_rotate_b(&ctx);
		test_two_towers_rotate_a(&ctx);
		test_two_towers_rotate_both(&ctx);
	}
	if (1)
	{
		test_two_towers_reverse_rotate_b(&ctx);
		test_two_towers_reverse_rotate_a(&ctx);
		test_two_towers_reverse_rotate_both(&ctx);
	}
}

void	simple_tests(void)
{
	t_two_towers_ctx	*ctx;

	printf("two_towers_initialize()...\n");
	two_towers_initialize(&ctx);
	test_two_towers_populate_simple_tests(&ctx);
	simple_tests_1(ctx);
	simple_tests_2(ctx);
	{
		printf("********************************************************\n");
	}
	two_towers_statistics(&ctx);
	printf("two_towers_finalize()...\n");
	two_towers_finalize(&ctx);
}

	//reverse_rotate_both(ctx);
	//	minmax_sort(ctx->stack_a, n);
	//	adapted_minmax_sort(ctx);
		//sort_simple(ctx);
		//sort_medium(ctx);
		//sort_complex(ctx);

void	algorithm_tests(void)
{
	t_two_towers_ctx	*ctx;

	printf("two_towers_initialize()...\n");
	two_towers_initialize(&ctx);
	test_two_towers_populate_algorithm_tests(&ctx);
	{
		printf("*******************************************************\n");
	}
	{
		printf("simple\n");
		sort_adaptive(ctx);
		two_towers_status(&ctx);
		two_towers_statistics(&ctx);
	}
	printf("two_towers_finalize()...\n");
	two_towers_finalize(&ctx);
}

int	main(int argc, char **argv)
{
	printf("hello two, you too, you tu, tower tu, tu tower, two tower s\n");
	
	algorithm_tests();
	simple_tests();
}
