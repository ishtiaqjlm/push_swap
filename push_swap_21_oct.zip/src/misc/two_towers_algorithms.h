/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_algorithms.h                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:32:30 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 13:35:17 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TWO_TOWERS_ALGORITHMS_H
# define TWO_TOWERS_ALGORITHMS_H

void	sort_simple(t_two_towers_ctx *ctx);
void	sort_medium(t_two_towers_ctx *ctx);
void	sort_complex(t_two_towers_ctx *ctx);
void	sort_adaptive(t_two_towers_ctx *ctx);
#endif	//TWO_TOWERS_ALGORITHMS_H
