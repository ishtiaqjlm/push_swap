/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_args.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/07 15:36:38 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/10/15 00:53:27 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "../../includes/push_swap.h"

static int	set_strategy(const char *name, t_config *config)
{
	if (ft_strcmp(name, "adaptive") == 0)
		config->strategy = STRAT_ADAPTIVE;
	else if (ft_strcmp(name, "simple") == 0)
		config->strategy = STRAT_SIMPLE;
	else if (ft_strcmp(name, "medium") == 0)
		config->strategy = STRAT_MEDIUM;
	else if (ft_strcmp(name, "complex") == 0)
		config->strategy = STRAT_COMPLEX;
	else
		return (0);
	return (1);
}

int	parse_args(int argc, char **argv, t_config *config)
{
	int	i;

	config->strategy = STRAT_ADAPTIVE;
	config->bench = 0;
	i = 1;
	while (i < argc)
	{
		if (ft_strcmp(argv[i], "--bench") == 0)
			config->bench = 1;
		else if (ft_strcmp(argv[i], "--strategy") == 0)
		{
			if (i + 1 >= argc || !set_strategy(argv[i + 1], config))
				return (-1);
			i++;
		}
		else
			return (i);
		i++;
	}
	return (i);
}
