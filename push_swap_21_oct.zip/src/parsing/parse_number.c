/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_number.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/07 16:44:23 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/10/15 00:53:39 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

static int	is_digit(char c)
{
	return (c >= '0' && c <= '9');
}

static int	get_sign(const char **str)
{
	int	sign;

	sign = 1;
	if (**str == '-' || **str == '+')
	{
		if (**str == '-')
			sign = -1;
		(*str)++;
	}
	return (sign);
}

static int	get_limit(int sign)
{
	if (sign == -1)
		return (INT_MIN);
	return (INT_MAX);
}

static int	read_digits(const char *str, int sign, int *number)
{
	long long	value;
	long long	limit;

	value = 0;
	limit = get_limit(sign);
	if (*str == '\0')
		return (0);
	while (*str)
	{
		if (!is_digit(*str))
			return (0);
		value = value * 10 + (*str - '0');
		if ((sign == 1 && value > limit)
			|| (sign == -1 && value > -limit))
			return (0);
		str++;
	}
	*number = (int)(value * sign);
	return (1);
}

int	parse_number(const char *str, int *number)
{
	int	sign;

	if (!str || !number || *str == '\0')
		return (0);
	sign = get_sign(&str);
	return (read_digits(str, sign, number));
}
