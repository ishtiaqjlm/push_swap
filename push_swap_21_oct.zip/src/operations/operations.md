===
	1.	sa	- (swap a)			- swap the first two elements at the top of stack a.

	2.	sb	- (swap b)			- swap the first two elements at the top of stack b.

	3.	ss	- (swap a;swap b)	- ss and sb at the same time.

--
	4.	pa	- (push a)	- take the first element at the top of b and put it at the top of a.
						- do nothing if b is empty.

	5.	pb	- (push b)	- take the first element at the top of a and put it at the top of b.
						- do nothing if a is empty.

--
	6.	ra	- (rotate a)			- shift up all elements of stack a by one.
									- the first element becomes the last one.

	7.	rb	- (rotate b)			- shift up all elements of stack b by one. 
									- the first element becomes the last one.

	8.	rr	- (rotate a;rotate b)	- ra and rb at the same time.

--
	9.	rra	- (r-rotate a)				- shift down all elements of stack a by one.
										- the last element becomes the first one.

	a.	rrb	- (r-rotate b)				- shift down all elements of stack b by one.
										- the last element becomes the first one.

	b.	rrr	- (r-rotate a;r-rotate b)	- rra and rrb at the same time.
