/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_operation_rrotate.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:19 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/15 02:07:53 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <two_towers.h>
#include <operations.h>

void    reverse_rotate_a(t_two_towers_ctx *ctx)
{
        if (ctx->stack_a->top > 0)
        {
                stack_rrotate(ctx->stack_a);
                ctx->statistics[OPERATIONS_RROTATE_A - 1]++;
                operation_output("rra");
        }
}

void    reverse_rotate_b(t_two_towers_ctx *ctx)
{
        if (ctx->stack_b->top > 0)
        {
                stack_rrotate(ctx->stack_b);
                ctx->statistics[OPERATIONS_RROTATE_B - 1]++;
                operation_output("rrb");
        }
}

void    reverse_rotate_both(t_two_towers_ctx *ctx)
{
        int     a;
        int     b;

        a = (ctx->stack_a->top > 0);
        b = (ctx->stack_b->top > 0);
        if (a || b)
        {
                if (a)
                        stack_rrotate(ctx->stack_a);
                if (b)
                        stack_rrotate(ctx->stack_b);
                ctx->statistics[OPERATIONS_RROTATE_BOTH - 1]++;
                operation_output("rrr");
        }
}
