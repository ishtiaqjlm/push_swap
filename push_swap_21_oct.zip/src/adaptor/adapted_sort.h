/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   adapted_sort.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:25:27 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 22:46:00 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ADAPTED_SORT_H
# define ADAPTED_SORT_H

void	adapted_minmax_sort(t_array_stack *s, size_t n);
void	adapted_shell_sort(t_array_stack *s, size_t n);
void	adapted_heap_sort(t_array_stack *s, size_t n);
void	adapted_adaptive_sort(t_array_stack *s, size_t n);
#endif // ADPATED_SORT_H
