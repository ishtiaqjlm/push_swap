/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   adapted_sort.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:25:43 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/15 01:32:26 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stack.h>
#include <intvector.h>
#include <algorithms.h>
#include <adapted_sort.h>

void	adapted_minmax_sort(t_array_stack *s, size_t n)
{
		int     *v;

        if (n < 2)
                return ;
        if (intvector_initialize(&v, n) == -1)
                return ;
        intvector_translate_from_stack(v, n, s);
        minmax_sort(v, n);
        intvector_translate_to_stack(v, n, s);
        intvector_finalize(&v, n);
}

void	adapted_shell_sort(t_array_stack *s, size_t n)
{
	int	*v;

	intvector_initialize(&v, n);
	intvector_translate_from_stack(v, n, s);
	shell_sort(v, n);
	intvector_translate_to_stack(v, n, s);
	intvector_finalize(&v, n);
}

void	adapted_heap_sort(t_array_stack *s, size_t n)
{
	int	*v;

	intvector_initialize(&v, n);
	intvector_translate_from_stack(v, n, s);
	heap_sort(v, n);
	intvector_translate_to_stack(v, n, s);
	intvector_finalize(&v, n);
}

void	adapted_adaptive_sort(t_array_stack *s, size_t n)
{
	int	*v;

	intvector_initialize(&v, n);
	intvector_translate_from_stack(v, n, s);
	adaptive_sort(v, n);
	intvector_translate_to_stack(v, n, s);
	intvector_finalize(&v, n);
}
