/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   03_complex__heap_sort.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:26:55 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 13:26:58 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// The heapsort algorithm begins by rearranging the array into a binary
// max-heap. The algorithm then repeatedly swaps the root of the heap
// (the greatest element remaining in the heap) with its last element,
// which is then declared to be part of the sorted suffix. Then
// the heap, which was damaged by replacing the root, is repaired
// so that the greatest element is again at the root. This repeats until
// only one value remains in the heap.

// https://en.wikipedia.org/wiki/Heapsort
// https://www.geeksforgeeks.org/dsa/heap-sort/

static int	_stack_get(int *v, int i)
{
	int	x;

	x = v[i];
	return (x);
}

static void	_stack_put(int *v, int i, int j)
{
	v[i] = j;
}

static void	stack_swap(int *v, int i, int j)
{
	int	z;

	z = _stack_get(v, i);
	_stack_put(v, i, _stack_get(v, j));
	_stack_put(v, j, z);
}

/*
static void	stack_swap(int *v, int i, int j)
{
	int	z;

	z = v[i];
	v[i] = v[j];
	v[j] = z;
}
*/

/*
static void	swapint(int *x, int *y)
{
	int	z;

	z = *x;
	*x = *y;
	*y = z;
}
*/

static void	heapify(int *v, int n, int i)
{
	int	largest;
	int	left;
	int	right;

	largest = i;
	left = 2 * i + 1;
	right = 2 * i + 2;
	if ((left < n) && (_stack_get(v, left) > _stack_get(v, largest)))
		largest = left;
	if ((right < n) && (_stack_get(v, right) > _stack_get(v, largest)))
		largest = right;
	if (largest != i)
	{
		stack_swap(v, i, largest);
		heapify(v, n, largest);
	}
}

void	heap_sort(int *v, int n)
{
	int	i;

	i = n / 2 - 1;
	while (i >= 0)
	{
		heapify(v, n, i);
		i--;
	}
	i = n - 1;
	while (i > 0)
	{
		stack_swap(v, 0, i);
		heapify(v, i, 0);
		i--;
	}
}
