/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   01_simple__minmax_sort.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:26:18 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 13:26:21 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// The min-max sorting algorithm works on the minimum and maximum elements of
// the array. It finds the minimum and maximum element from the array and
// set them on the first and last position of the array. Then the array index
// increment from the first position and decrement from the last position
// to get the new array. From this new array, it again finds the minimum and
// maximum element and set on their respective positions.
// In this way, this sorting algorithm sorts the elements of the array.

// https://www.ijert.org/research/
// a-new-approach-to-sorting-min-max-sorting-algorithm-IJERTV2IS50210.pdf

static int	_stack_get(int *v, int i)
{
	int	x;

	x = v[i];
	return (x);
}

static void	_stack_put(int *v, int i, int j)
{
	v[i] = j;
}

static void	stack_swap(int *v, int i, int j)
{
	int	z;

	z = _stack_get(v, i);
	_stack_put(v, i, _stack_get(v, j));
	_stack_put(v, j, z);
}

/*
static void	stack_swap(int *v, int i, int j)
{
//	int	z;
//	z = v[i];
//	v[i] = v[j];
//	v[j] = z;

	// v[i]
	// get shortest left/right i, m
	push into b

	// v[j]
	// get shortest left/right j
	// 	[ path n ]
	// push into b
	
	push into a
	// operations n
	push into a
	// operations m
}
*/

/*
static void	stack_swap(int *v, int i, int j)
{
	int	z;
	z = v[i];
	v[i] = v[j];
	v[j] = z;
}
*/

/*
static void	swapint(int *x, int *y)
{
	int	z;

	z = *x;
	*x = *y;
	*y = z;
}
*/

static void	minmax_apply(int *v, int first, int last)
{
	int	i;

	i = first;
	while (i < last)
	{
		if (_stack_get(v, i) < _stack_get(v, first))
			stack_swap(v, i, first);
		if (_stack_get(v, i) > _stack_get(v, last))
			stack_swap(v, i, last);
		i++;
	}
}

void	minmax_sort(int *v, int n)
{
	int	first;
	int	last;

	first = 0;
	last = n - 1;
	while (first < last)
	{
		minmax_apply(v, first, last);
		first++;
		last--;
	}
}
