/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:57 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 02:27:51 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <limits.h>
#include <stack.h>
#include <libft.h>

int	stack_initialize(t_array_stack **pstack, char *name)
{
	t_array_stack	*stack;
	size_t	dcapacity;
	size_t	n;
	int		*data;

	dcapacity = 16;
	if (dcapacity >= ((UINT_MAX - 1) / sizeof(int)))
		return (-1);
	stack = malloc(sizeof(t_array_stack));
	if (stack == NULL)
		return (-1);
	n = dcapacity * sizeof(int);
	data = malloc(n);
	if (data == NULL)
	{
		free(stack);
		return (-1);
	}
	ft_memset(data, 0, n);
	stack->name = name;
	stack->capacity = dcapacity;
	stack->top = (size_t) - 1;
	stack->data = data;
	*pstack = stack;
	return (0);
}

int	stack_finalize(t_array_stack **pstack)
{
	t_array_stack	*stack;

	stack = *pstack;
	free(stack->data);
	free(stack);
	return (0);
}



static int	stack_grow(t_array_stack *stack)
{
	size_t	new_capacity;
	size_t	i;
	int		*new_data;

	if (stack->capacity > (size_t)-1 / 2 / sizeof(int))
		return (-1);
	new_capacity = stack->capacity * 2;
	new_data = malloc(new_capacity * sizeof(int));
	if (new_data == NULL)
		return (-1);
	i = 0;
	while (i <= stack->top)
	{
		new_data[i] = stack->data[i];
		i++;
	}
	free(stack->data);
	stack->data = new_data;
	stack->capacity = new_capacity;
	return (0);
}

int	stack_push(t_array_stack *stack, t_stack_element *e)
{
	if (stack->top == stack->capacity - 1)
	{
		if (stack_grow(stack) == -1)
			return (-1);
	}
	stack->top++;
	stack->data[stack->top] = *e;
	return (0);
}

int	stack_pop(t_array_stack *stack, t_stack_element *e)
{
	t_stack_element	_e;

	if (stack->top == (size_t)-1)
		return (-1);
	_e = stack->data[stack->top];
	stack->top--;
	*e = _e;
	return (0);
}
