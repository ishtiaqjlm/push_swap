/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algorithms.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:27:21 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 01:38:18 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ALGORITHMS_H
# define ALGORITHMS_H
# include "two_towers.h"

void	minmax_sort(int *v, size_t n);
void	shell_sort(int *v, size_t n);
void	heap_sort(int *v, size_t n);
void	adaptive_sort(int *v, size_t n);
void	sort_two(t_two_towers_ctx *ctx);
void	sort_three(t_two_towers_ctx *ctx);
void	sort_simple_general(t_two_towers_ctx *ctx);
void    sort_medium(t_two_towers_ctx *ctx);
int	is_sorted(t_array_stack *stack);
int	normalize_ranks(t_array_stack *stack);
void	push_range(t_two_towers_ctx *ctx, size_t low, size_t high);
void	reconstruct_stack(t_two_towers_ctx *ctx);
double	compute_disorder(int *v, size_t n);
int		_xlat_initialize(t_two_towers_ctx *ctx, size_t n, long int **pzsubset);
int		_xlat_reorder(
			t_two_towers_ctx *ctx,
			size_t *xlat_table, long int *zsubset, size_t n);
int		_xlat_finalize(long int	*zsubset, size_t n);
void	init_xlat_from_zsubset_to_nonnegative_integers(
			t_two_towers_ctx *ctx,
			size_t *xlat_table, size_t xlat_table_length);
size_t	xlat_from_zsubset_to_nonnegative_integers(
			size_t x,
			size_t *xlat_table, size_t xlat_table_length);
void	two_towers_radix_sort(t_two_towers_ctx *ctx);
#endif	// ALGORITHMS_H
