#ifndef BENCH_H
# define BENCH_H
/* benchmark */
void run_bench(t_two_towers_ctx *ctx, t_config *config, double disorder);
void print_detail_operation(t_two_towers_ctx *ctx);
#endif
