/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/* ************************************************************************** */

#include "push_swap.h"
#include <two_towers.h>
#include <libft.h>
#include <stdlib.h>
#include <stddef.h>
#include <bench.h>
#include <algorithms.h>

static void print_error(void)
{
    write(2, "Error\n", 6);
}

	static void run_strategy(t_two_towers_ctx *ctx, t_config *config)
{
	//config->strategy = STRAT_MEDIUM;
	if (config->strategy == STRAT_SIMPLE)
    {
        //write(2, "SIMPLE\n", 7);
        sort_simple(ctx);
    }
    else if (config->strategy == STRAT_MEDIUM)
    {
        //write(2, "MEDIUM\n", 7);
        sort_medium(ctx);
    }
    else if (config->strategy == STRAT_COMPLEX)
    {
        //write(2, "COMPLEX\n", 8);
        sort_complex(ctx);
    }
    else
    {
        //write(2, "ADAPTIVE\n", 9);
        sort_adaptive(ctx);
    }
}

static int	load_numbers(int argc, char **argv, int start,
				int **numbers, size_t *count)
{
	int		i;
	int		j;

	*count = (size_t)(argc - start);
	*numbers = malloc(sizeof(int) * *count);
	if (*numbers == NULL)
		return (0);
	i = 0;
	while (i < (int)*count)
	{
		if (!parse_number(argv[start + i], &(*numbers)[i]))
			return (free(*numbers), *numbers = NULL, 0);
		j = 0;
		while (j < i)
		{
			if ((*numbers)[j] == (*numbers)[i])
				return (free(*numbers), *numbers = NULL, 0);
			j++;
		}
		i++;
	}
	return (1);
}

int	main(int argc, char **argv)
{
	t_config			config;
	t_two_towers_ctx	*ctx;
	int					start;
	int					*numbers;
	size_t				count;
	double				disorder;
	//size_t				i;

	if (argc == 1)
		return (0);
	start = parse_args(argc, argv, &config);
	if (start < 0)
    	return (print_error(), 1);
	if (start >= argc)
		return (0);
	if (!load_numbers(argc, argv, start, &numbers, &count))
	{
		write(2, "ERROR: load_numbers\n", 20);
		return (1);
	}
	if (two_towers_initialize(&ctx) == -1)
		return (free(numbers), print_error(), 1);
	if (two_towers_populate(&ctx, numbers, count) == -1)
		return (free(numbers), two_towers_finalize(&ctx),
			print_error(), 1);
	free(numbers);
	/*i = 0;
	while (i <= ctx->stack_a->top)
	{
		ft_putnbr_fd(ctx->stack_a->data[i], 2);
		write(2, " ", 1);
		i++;
	}
	write(2, "\n", 1);*/
	disorder = compute_disorder(ctx->stack_a->data, ctx->stack_a->top + 1);
	run_strategy(ctx, &config);
	if (config.bench)
    	run_bench(ctx, &config, disorder);
	two_towers_finalize(&ctx);
	return (0);
}
