/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   medium_sort.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/22 16:50:30 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/10/23 01:01:32 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>
#include <stdlib.h>
#include <stack.h>
#include <two_towers.h>

static size_t get_range_size(size_t n)
{
    size_t range;

    range = 1;
    while (range < n / range)
        range++;
    return (range);
}

static int normalize_ranks(t_array_stack *stack)
{
    size_t n;
    size_t i;
    size_t j;
    size_t rank;
    int *values;
    int *ranks;

    if (stack->top == (size_t)-1)
        return (0);
    n = stack->top + 1;
    values = malloc(sizeof(int) * n);
    ranks = malloc(sizeof(int) * n);
    if (!values || !ranks)
    {
        free(values);
        free(ranks);
        return (-1);
    }
    i = 0;
    while (i < n)
    {
        values[i] = stack->data[i];
        i++;
    }
    i = 0;
    while (i < n)
    {
        rank = 0;
        j = 0;
        while (j < n)
        {
            if (values[j] < values[i])
                rank++;
            j++;
        }
        ranks[i] = (int)rank;
        i++;
    }
    i = 0;
    while (i < n)
    {
        stack->data[i] = ranks[i];
        i++;
    }
    free(values);
    free(ranks);
    return (0);
}

static size_t count_range(t_array_stack *stack, size_t low, size_t high)
{
    size_t i;
    size_t count;

    count = 0;
    if (stack->top == (size_t)-1)
        return (0);
    i = 0;
    while (i <= stack->top)
    {
        if (stack->data[i] >= (int)low
            && stack->data[i] <= (int)high)
            count++;
        i++;
    }
    return (count);
}

static size_t find_max_position(t_array_stack *stack)
{
    size_t i;
    size_t max_pos;

    max_pos = stack->top;
    i = stack->top;
    while (i > 0)
    {
        i--;
        if (stack->data[i] > stack->data[max_pos])
            max_pos = i;
    }
    return (max_pos);
}

static void bring_max_to_top(t_two_towers_ctx *ctx, size_t max_pos)
{
    size_t forward;
    size_t reverse;

    forward = ctx->stack_b->top - max_pos;
    reverse = max_pos + 1;
    if (forward <= reverse)
    {
        while (forward > 0)
        {
            rotate_b(ctx);
            forward--;
        }
    }
    else
    {
        while (reverse > 0)
        {
            reverse_rotate_b(ctx);
            reverse--;
        }
    }
}

static void reconstruct_stack(t_two_towers_ctx *ctx)
{
    size_t max_pos;

    while (ctx->stack_b->top != (size_t)-1)
    {
        max_pos = find_max_position(ctx->stack_b);
        bring_max_to_top(ctx, max_pos);
        push_a(ctx);
    }
}

static void push_range(t_two_towers_ctx *ctx,
        size_t low, size_t high)
{
    size_t remaining;
    int rank;

    remaining = count_range(ctx->stack_a, low, high);
    while (remaining > 0)
    {
        rank = ctx->stack_a->data[ctx->stack_a->top];
        if (rank >= (int)low && rank <= (int)high)
        {
            push_b(ctx);
            if (rank < (int)((low + high) / 2) && ctx->stack_b->top > 0)
                rotate_b(ctx);
            remaining--;
        }
        else
            rotate_a(ctx);
    }
}

static void partition_ranges(t_two_towers_ctx *ctx, size_t n)
{
    size_t low;
    size_t high;
    size_t range;

    low = 0;
    range = get_range_size(n);
    while (low < n)
    {
        high = low + range - 1;
        if (high >= n)
            high = n - 1;
        push_range(ctx, low, high);
        low = high + 1;
    }
}

void    sort_medium(t_two_towers_ctx *ctx)
{
    size_t n;

    if (ctx->stack_a->top == (size_t)-1)
        return ;
    n = ctx->stack_a->top + 1;
    if (n < 2)
        return ;
    if (normalize_ranks(ctx->stack_a) == -1)
        return ;
    partition_ranges(ctx, n);
    reconstruct_stack(ctx);
}

