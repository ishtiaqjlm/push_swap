/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   02_medium__shell_sort.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:26:44 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/22 23:11:29 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Shell sort is an in-place comparison sort. It can be understood as either
// a generalization of sorting by exchange (bubble sort) or sorting by
// insertion (insertion sort).
// The algorithm starts by sorting pairs of elements far apart
// from each other, then progressively reducing the gap between elements
// to be compared. By starting with far-apart elements, it can move some
// out-of-place elements into the position faster than a simple
// nearest-neighbor exchange.

// https://en.wikipedia.org/wiki/Shellsort
// https://www.geeksforgeeks.org/dsa/shell-sort/

static int	_stack_get(int *v, int i)
{
	int	x;

	x = v[i];
	return (x);
}

static	void	_stack_put(int *v, int i, int j)
{
	v[i] = j;
}

void	shell_sort(int *v, int n)
{
	int	gap;
	int	i;
	int	j;
	int	z;
	gap = n;
	while (gap > 0)
	{
		gap = gap / 2;
		i = gap;
		while (i < n)
		{
			z = _stack_get(v, i);
			j = i;
			while ((j >= gap) && (_stack_get(v, j - gap) > z))
			{
				_stack_put(v, j, _stack_get(v, j - gap));
				j = j - gap;
			}
			_stack_put(v, j, z);
			i++;
		}
	}
}
