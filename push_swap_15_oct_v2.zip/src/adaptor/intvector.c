/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   intvector.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:24:41 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/15 01:01:56 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include "stack.h"

int	intvector_initialize(int **pv, size_t n)
{
	int		*v;
	size_t	m;

	m = n * sizeof(int);
	if (m < n)
		return (-1);
	v = malloc(m);
	if (v == NULL)
		return (-1);
	*pv = v;
	return (0);
}

int	intvector_finalize(int **pv, size_t n)
{
	int	*v;

	n--;
	n++;
	v = *pv;
	free(v);
	return (0);
}

int	intvector_translate_from_stack(int *v, size_t n, t_array_stack *stack)
{
	size_t			i;
	t_stack_element	element;

	i = 0;
	while (i < n)
	{
		stack_pop(stack, &element);
		v[i] = element;
		i++;
	}
	return (0);
}

int	intvector_translate_to_stack(int *v, size_t n, t_array_stack *stack)
{
	size_t			i;
	t_stack_element	element;

	i = 0;
	while (i < n)
	{
		element = v[i];
		stack_push(stack, &element);
		i++;
	}
	return (0);
}
