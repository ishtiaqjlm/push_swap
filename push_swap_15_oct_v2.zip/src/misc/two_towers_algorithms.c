/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_algorithms.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:31:49 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/15 15:40:21 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <two_towers.h>
#include <libft.h>
//#include <algorithms.h>
#include <adapted_sort.h>

void	sort_simple(t_two_towers_ctx *ctx)
{
	size_t	n;
	t_array_stack	*stack;

	stack = ctx->stack_a;
	if (ctx->stack_a->top == (size_t)-1)
    	return ;
	n = ctx->stack_a->top + 1;
	adapted_minmax_sort(stack, n);
}

void	sort_medium(t_two_towers_ctx *ctx)
{
	size_t	n;
	t_array_stack	*stack;

	stack = ctx->stack_a;
	if (ctx->stack_a->top == (size_t)-1)
    	return ;
	n = ctx->stack_a->top + 1;
	adapted_shell_sort(stack, n);
}

void	sort_complex(t_two_towers_ctx *ctx)
{
	size_t	n;
	t_array_stack	*stack;

	stack = ctx->stack_a;
	if (ctx->stack_a->top == (size_t)-1)
    	return ;
	n = ctx->stack_a->top + 1;
	adapted_heap_sort(stack, n);
}

void	sort_adaptive(t_two_towers_ctx *ctx)
{
	size_t	n;
	t_array_stack	*stack;

	stack = ctx->stack_a;
	if (ctx->stack_a->top == (size_t)-1)
    	return ;
	n = ctx->stack_a->top + 1;
	adapted_adaptive_sort(stack, n);
}
