/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   04_adaptive__adaptive_sort.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:27:10 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/19 18:01:45 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	minmax_sort(int *v, int n);
void	shell_sort(int *v, int n);
void	heap_sort(int *v, int n);

void	low_disorder_sort(int *v, int n)
{
	printf("disorder: low => minmax_sort\n");
	minmax_sort(v, n);
}

void	medium_disorder_sort(int *v, int n)
{
	printf("disorder: medium => shell_sort\n");
	shell_sort(v, n);
}

void	high_disorder_sort(int *v, int n)
{
	printf("disorder: high => heap_sort\n");
	heap_sort(v, n);
}

double	compute_disorder(int *v, int n)
{
	int		mistakes;
	int		total_pairs;
	int		i;
	int		j;
	float	disorder;

	mistakes = 0;
	total_pairs = 0;
	i = 0;
	while (i < n - 1)
	{
		j = i + 1;
		while (j < n)
		{
			total_pairs++;
			if (v[i] > v[j])
				mistakes += 1;
			j++;
		}
		i++;
	}
	disorder = (float)mistakes / (float)total_pairs;
	return (disorder);
}

void	adaptive_sort(int *v, int n)
{
	double	disorder;

	disorder = compute_disorder(v, n);
	printf("disorder: %f\n", disorder);
	if (disorder < 0.2)
		low_disorder_sort(v, n);
	if ((0.2 <= disorder) && (disorder < 0.5))
		medium_disorder_sort(v, n);
	if (disorder >= 0.5)
		high_disorder_sort(v, n);
}
