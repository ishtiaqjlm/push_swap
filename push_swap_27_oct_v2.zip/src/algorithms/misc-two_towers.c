
#include <stack.h>
#include <stdio.h>	// XXX

#include <two_towers.h>


int	tt_stack_get(t_two_towers_ctx *ctx, int i)
{
	int	x;
	int y;
	t_array_stack *s;
	size_t r;

	s = ctx->stack_a;

//	x = s->data[i];		// XXX this is a push b;

	{
		if (0)
		{
			r = 0;
			while (r < ctx->stack_a->top - i)
			{
				rotate_a(ctx);
				r++;
			}
		}
		else
		{
			r = 0;
			while (r < (size_t)(i + 1))	// cast
			{
				reverse_rotate_a(ctx);
				r++;
			}
		}

		y = s->data[s->top]; // XXX this is a push b; move from a to b
		x = y;				// XXX
		if (x != y) printf("!!! x != y; %02d != %02d\n", x, y);
		if (0)
		{
			r = 0;
			while (r < ctx->stack_a->top - i)
			{
				reverse_rotate_a(ctx);
				r++;
			}
		}
		else
		{
			r = 0;
			while (r < (size_t)(i + 1))	// XXX cast
			{
				rotate_a(ctx);
				r++;
			}
		}
	}

	return (x);
}

void	tt_stack_put(t_two_towers_ctx *ctx, int i, int x)
{
	t_array_stack *s;
	size_t r;
	int y;
	
	(void)y;

	s = ctx->stack_a;

	// original
	// s->data[i] = x;		// this is a push b

	{
		if (1)
		{
			r = 0;
			while (r < (size_t)(ctx->stack_a->top - i))		// cast
			{
				rotate_a(ctx);
				r++;
			}
		}
		else
		{
			r = 0;
			while (r < (size_t)(i + 1))
			{
				reverse_rotate_a(ctx);
				r++;
			}
		}
//		y = s->data[s->top];
//		if (y != x) printf("s->data[s->top] != x\n");
		s->data[s->top] = x;	// this is a push

		if (1)
		{
			r = 0;
			while (r < (size_t)(ctx->stack_a->top - i))	// XXX cast
			{
				reverse_rotate_a(ctx);
				r++;
			}
		}
		else
		{
			r = 0;
			while (r < (size_t)(i + 1))					// XXX cast
			{
				rotate_a(ctx);
				r++;
			}
		}
	}
}


