/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   04_adaptive__adaptive_sort-two_towers.c            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:27:10 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/22 16:13:49 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>      // XXX
#include <two_towers.h>

void	two_towers_minmax_sort(t_two_towers_ctx *ctx);
void	two_towers_shell_sort(t_two_towers_ctx *ctx);
void	two_towers_heap_sort(t_two_towers_ctx *ctx);

static void	low_disorder_sort(t_two_towers_ctx *ctx)
{
	printf("disorder: low => minmax_sort[tt]\n");
	two_towers_minmax_sort(ctx);
}

static void	medium_disorder_sort(t_two_towers_ctx *ctx)
{
	printf("disorder: medium => shell_sort [tt]\n");
	two_towers_shell_sort(ctx);
}

static void	high_disorder_sort(t_two_towers_ctx *ctx)
{
	printf("disorder: high => heap_sort [tt]\n");
	two_towers_heap_sort(ctx);
}

static double	compute_disorder(t_two_towers_ctx *ctx)
{
	int		mistakes;
	int		total_pairs;
	size_t	i;
	size_t	j;
	float	disorder;

	t_array_stack *stack_a;
	int *v;
	size_t n;
	// TODO: count stack operations

    stack_a = ctx->stack_a;
	v = stack_a->data;
    n = ctx->stack_a->top + 1;

	printf("v[i],     v[j]\n");
	mistakes = 0;
	total_pairs = 0;
	i = 0;
	while (i < n - 1)
	{
		j = i + 1;
//		while (j < n - 1)
		while (j < n)
		{
			{
				printf("v[%zu]: %02d, v[%zu]: %02d\n", i, v[i], j, v[j]);
			}
			total_pairs++;
			if (v[i] > v[j])
				mistakes += 1;
			j++;
		}
		i++;
	}
	disorder = (float)mistakes / (float)total_pairs;
	return (disorder);
}

void	two_towers_adaptive_sort(t_two_towers_ctx *ctx)
{
	double	disorder;

	printf("two_towers_adaptive_sort()\n");
	disorder = compute_disorder(ctx);
	printf("disorder: %f\n", disorder);
	if (disorder < 0.2)
		low_disorder_sort(ctx);
	if ((0.2 <= disorder) && (disorder < 0.5))
		medium_disorder_sort(ctx);
	if (disorder >= 0.5)
		high_disorder_sort(ctx);
/*
	{
		printf("disorder: %f\n", disorder);
		printf("overriding disorder, low_disorder_sort()\n");
		low_disorder_sort(ctx);
	}
*/
}
