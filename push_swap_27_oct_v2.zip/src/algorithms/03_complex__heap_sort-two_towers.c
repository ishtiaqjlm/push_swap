/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   03_complex__heap_sort-two_towers.c                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:26:55 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/22 16:13:24 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// The heapsort algorithm begins by rearranging the array into a binary
// max-heap. The algorithm then repeatedly swaps the root of the heap
// (the greatest element remaining in the heap) with its last element,
// which is then declared to be part of the sorted suffix. Then
// the heap, which was damaged by replacing the root, is repaired
// so that the greatest element is again at the root. This repeats until
// only one value remains in the heap.

// https://en.wikipedia.org/wiki/Heapsort
// https://www.geeksforgeeks.org/dsa/heap-sort/

#include <stdio.h>      // XXX
#include <two_towers.h>

int		tt_stack_get(t_two_towers_ctx *ctx, int i);			// XXX
void	tt_stack_put(t_two_towers_ctx *ctx, int i, int x);  // XXX

static int  _stack_get(t_two_towers_ctx *ctx, int i)
{
	return (tt_stack_get(ctx, i));
}

static void _stack_put(t_two_towers_ctx *ctx, int i, int x)
{
    tt_stack_put(ctx, i, x);
}


static void	_stack_swap(t_two_towers_ctx *ctx, int i, int j)
{
	int	z;

	z = _stack_get(ctx, i);
	_stack_put(ctx, i, _stack_get(ctx, j));
	_stack_put(ctx, j, z);
}

/*
static int	_stack_get(int *v, int i)
{
	int	x;

	x = v[i];
	return (x);
}
*/

/*
static void	_stack_put(int *v, int i, int j)
{
	v[i] = j;
}
*/

/*
static void	stack_swap(int *v, int i, int j)
{
	int	z;

	z = _stack_get(v, i);
	_stack_put(v, i, _stack_get(v, j));
	_stack_put(v, j, z);
}
*/

/*
static void	stack_swap(int *v, int i, int j)
{
	int	z;

	z = v[i];
	v[i] = v[j];
	v[j] = z;
}
*/

/*
static void	swapint(int *x, int *y)
{
	int	z;

	z = *x;
	*x = *y;
	*y = z;
}
*/

static void	heapify(t_two_towers_ctx *ctx , int n, int i)
{
	int	largest;
	int	left;
	int	right;

	largest = i;
	left = 2 * i + 1;
	right = 2 * i + 2;
	if ((left < n) && (_stack_get(ctx, left) > _stack_get(ctx, largest)))
		largest = left;
	if ((right < n) && (_stack_get(ctx, right) > _stack_get(ctx, largest)))
		largest = right;
	if (largest != i)
	{
		_stack_swap(ctx, i, largest);
		heapify(ctx, n, largest);
	}
}

void	two_towers_heap_sort(t_two_towers_ctx *ctx)
{
	int	i;
    int n;
    t_array_stack   *s;

    s = ctx->stack_a;
    n = ctx->stack_a->top + 1;

    printf("two_towers_heap_sort()\n");

	i = n / 2 - 1;
	while (i >= 0)
	{
		heapify(ctx, n, i);
		i--;
	}
	i = n - 1;
	while (i > 0)
	{
		_stack_swap(ctx, 0, i);
		heapify(ctx, i, 0);
		i--;
	}
}
