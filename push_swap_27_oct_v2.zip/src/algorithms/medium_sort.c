/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   medium_sort.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/22 16:50:30 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/10/27 12:52:17 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>
#include <stdlib.h>
#include <stack.h>
#include <two_towers.h>
#include <algorithms.h>

static size_t	get_range_size(size_t n)
{
	size_t	range;

	range = 1;
	while (range < n / range)
		range++;
	return (range);
}

static void	partition_ranges(t_two_towers_ctx *ctx, size_t n)
{
	size_t	low;
	size_t	high;
	size_t	range;

	low = 0;
	range = get_range_size(n);
	while (low < n)
	{
		high = low + range - 1;
		if (high >= n)
			high = n - 1;
		push_range(ctx, low, high);
		low = high + 1;
	}
}

void	sort_medium(t_two_towers_ctx *ctx)
{
	size_t	n;

	if (ctx->stack_a->top == (size_t)-1)
		return ;
	if (is_sorted(ctx->stack_a))
		return ;
	n = ctx->stack_a->top + 1;
	if (n < 2)
		return ;
	if (normalize_ranks(ctx->stack_a) == -1)
		return ;
	partition_ranges(ctx, n);
	reconstruct_stack(ctx);
}
