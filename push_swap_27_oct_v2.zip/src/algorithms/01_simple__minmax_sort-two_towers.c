/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   01_simple__minmax_sort-two_towers.c                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:26:18 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/26 14:04:33 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// The min-max sorting algorithm works on the minimum and maximum elements of
// the array. It finds the minimum and maximum element from the array and
// set them on the first and last position of the array. Then the array index
// increment from the first position and decrement from the last position
// to get the new array. From this new array, it again finds the minimum and
// maximum element and set on their respective positions.
// In this way, this sorting algorithm sorts the elements of the array.

// https://www.ijert.org/research/
// a-new-approach-to-sorting-min-max-sorting-algorithm-IJERTV2IS50210.pdf

//	x = v[i];
#include <stack.h>
#include <stdio.h>	// XXX

#include <two_towers.h>

int	tt_stack_get(t_two_towers_ctx *ctx, int i);				// XXX
void	tt_stack_put(t_two_towers_ctx *ctx, int i, int x);	// XXX

static int	_stack_get(t_two_towers_ctx *ctx, int i)
{
	return (tt_stack_get(ctx, i));
}

static void	_stack_put(t_two_towers_ctx *ctx, int i, int x)
{
	tt_stack_put(ctx, i, x);
}

/*
static int	_stack_get(t_array_stack *stack, int i)
{
	int	x;
	int n;
//	int j;

	printf("top: %zu\n", stack->top);		// XXX

	if (stack->top == (size_t)-1)
		return (-1);

	if (stack->top == 0)
		return (stack->data[0]);

	n = stack->top - i;
	if (n == 0)
		return (-1);


	j = 0;
	while (j != n)
	{
		stack_rotate(stack);
		j++;
	}

	x = stack->data[stack->top];

	n = stack->top - i;
	j = 0;
	while (j != n)
	{
		stack_rrotate(stack);
		j++;
	}
	return (x);
}
*/

/*
//	v[i] = x;
static void	_stack_put(t_array_stack *s, int i, int x)
{
	int n;
	int j;

	n = s->capacity - i;
	j = 0;
	while (j != n)
	{
		stack_rotate(s);
		j++;
	}
	s->data[s->top] = x;
	n = s->capacity - i;
	while (j != n)
	{
		stack_rrotate(s);
		j++;
	}
	return;
}
*/



/*
static int	_stack_get(int *v, int i)
{
	int	x;

	x = v[i];
	return (x);
}

static void	_stack_put(int *v, int i, int x)
{
	v[i] = x;
}
*/

//static void	_stack_swap(t_array_stack *s, int i, int j)
static void	_stack_swap(t_two_towers_ctx *ctx, int i, int j)
{
	int	z;

	z = _stack_get(ctx, i);
	_stack_put(ctx, i, _stack_get(ctx, j));
	_stack_put(ctx, j, z);
}

/*
static void	stack_swap(int *v, int i, int j)
{
	int	z;
	z = v[i];
	v[i] = v[j];
	v[j] = z;
}
*/

/*
static void	swapint(int *x, int *y)
{
	int	z;

	z = *x;
	*x = *y;
	*y = z;
}
*/

static void	minmax_apply(t_two_towers_ctx *ctx, int first, int last)
{
	int	i;

	i = first;
	while (i < last)
	{
		if (_stack_get(ctx, i) < _stack_get(ctx, first))
			_stack_swap(ctx, i, first);
		if (_stack_get(ctx, i) > _stack_get(ctx, last))
			_stack_swap(ctx, i, last);
		i++;
	}
}

void	two_towers_minmax_sort(t_two_towers_ctx *ctx)
{
	int				first;
	int				last;
	size_t			n;
	t_array_stack	*s;

	s = ctx->stack_a;
	n = ctx->stack_a->top + 1;

	printf("two_towers_minmax_sort()\n");
	first = 0;
	last = n - 1;
	while (first < last)
	{
		minmax_apply(ctx, first, last);
		first++;
		last--;
	}
}
