/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   medium_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/27 12:02:19 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/10/27 12:59:00 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stack.h>
#include <two_towers.h>
#include <algorithms.h>

static size_t	count_range(t_array_stack *stack, size_t low, size_t high)
{
	size_t	i;
	size_t	count;

	count = 0;
	if (stack->top == (size_t)-1)
		return (0);
	i = 0;
	while (i <= stack->top)
	{
		if (stack->data[i] >= (int)low && stack->data[i] <= (int)high)
			count++;
		i++;
	}
	return (count);
}

void	push_range(t_two_towers_ctx *ctx, size_t low, size_t high)
{
	size_t	remaining;
	int		rank;

	remaining = count_range(ctx->stack_a, low, high);
	while (remaining > 0)
	{
		rank = ctx->stack_a->data[ctx->stack_a->top];
		if (rank >= (int)low && rank <= (int)high)
		{
			push_b(ctx);
			if (rank < (int)((low + high) / 2) && ctx->stack_b->top > 0)
				rotate_b(ctx);
			remaining--;
		}
		else
			rotate_a(ctx);
	}
}
