/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   02_medium__shell_sort-two_towers.c                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:26:44 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/22 16:13:16 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Shell sort is an in-place comparison sort. It can be understood as either
// a generalization of sorting by exchange (bubble sort) or sorting by
// insertion (insertion sort).
// The algorithm starts by sorting pairs of elements far apart
// from each other, then progressively reducing the gap between elements
// to be compared. By starting with far-apart elements, it can move some
// out-of-place elements into the position faster than a simple
// nearest-neighbor exchange.

// https://en.wikipedia.org/wiki/Shellsort
// https://www.geeksforgeeks.org/dsa/shell-sort/

#include <stdio.h>		// XXX
#include <two_towers.h>

int tt_stack_get(t_two_towers_ctx *ctx, int i);				// XXX
void	tt_stack_put(t_two_towers_ctx *ctx, int i, int x);	// XXX

static int  _stack_get(t_two_towers_ctx *ctx, int i)
{   
	return (tt_stack_get(ctx, i));
}

static void _stack_put(t_two_towers_ctx *ctx, int i, int x)
{   
	tt_stack_put(ctx, i, x);
}

/*
static int	_stack_get(int *v, int i)
{
	int	x;

	x = v[i];
	return (x);
}
*/

/*
static	void	_stack_put(int *v, int i, int j)
{
	v[i] = j;
}
*/

void	two_towers_shell_sort(t_two_towers_ctx *ctx)
{
	int	gap;
	int	i;
	int	j;
	int	z;
	int n;
	t_array_stack   *s;

	s = ctx->stack_a;
	n = ctx->stack_a->top + 1;

	printf("two_towers_shell_sort()\n");

	gap = n;
	while (gap > 0)
	{
		gap = gap / 2;
		i = gap;
		while (i < n)
		{
			z = _stack_get(ctx, i);
			j = i;
			while ((j >= gap) && (_stack_get(ctx, j - gap) > z))
			{
				_stack_put(ctx, j, _stack_get(ctx, j - gap));
				j = j - gap;
			}
			_stack_put(ctx, j, z);
			i++;
		}
	}
}
