/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_operation_swap.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:25 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 14:44:03 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <two_towers.h>
#include <libft.h>
#include <operations.h>

void	swap_a(t_two_towers_ctx *ctx)
{
	ctx->statistics[OPERATIONS_SWAP_A - 1]++;
	stack_swap(ctx->stack_a);
}

void	swap_b(t_two_towers_ctx *ctx)
{
	ctx->statistics[OPERATIONS_SWAP_B - 1]++;
	stack_swap(ctx->stack_b);
}

void	swap_ab(t_two_towers_ctx *ctx)
{
	ctx->statistics[OPERATIONS_SWAP_BOTH - 1]++;
	stack_swap(ctx->stack_a);
	stack_swap(ctx->stack_b);
}
