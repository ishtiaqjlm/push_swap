/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_operation_rotate.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:13 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 14:43:33 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <two_towers.h>
#include <libft.h>
#include <operations.h>

void	rotate_a(t_two_towers_ctx *ctx)
{
	ctx->statistics[OPERATIONS_ROTATE_A - 1]++;
	stack_rotate(ctx->stack_a);
}

void	rotate_b(t_two_towers_ctx *ctx)
{
	ctx->statistics[OPERATIONS_ROTATE_B - 1]++;
	stack_rotate(ctx->stack_b);
}

void	rotate_both(t_two_towers_ctx *ctx)
{
	ctx->statistics[OPERATIONS_ROTATE_BOTH - 1]++;
	stack_rotate(ctx->stack_a);
	stack_rotate(ctx->stack_b);
}
