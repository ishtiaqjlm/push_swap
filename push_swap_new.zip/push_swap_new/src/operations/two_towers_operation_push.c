/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_operation_push.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:04 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 14:43:21 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <two_towers.h>
#include <libft.h>
#include <operations.h>

void	push_a(t_two_towers_ctx *ctx)
{
	t_stack_element	e;

	ctx->statistics[OPERATIONS_PUSH_A - 1]++;
	stack_pop(ctx->stack_b, &e);
	stack_push(ctx->stack_a, &e);
}

void	push_b(t_two_towers_ctx *ctx)
{
	t_stack_element	e;

	ctx->statistics[OPERATIONS_PUSH_B - 1]++;
	stack_pop(ctx->stack_a, &e);
	stack_push(ctx->stack_b, &e);
}
