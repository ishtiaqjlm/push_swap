/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:30 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 13:28:34 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef OPERATIONS_H
# define OPERATIONS_H
# define OPERATIONS_SWAP_A 			0x1
# define OPERATIONS_SWAP_B 			0x2
# define OPERATIONS_SWAP_BOTH		0x3
# define OPERATIONS_PUSH_A 			0x4
# define OPERATIONS_PUSH_B 			0x5
# define OPERATIONS_ROTATE_A		0x6
# define OPERATIONS_ROTATE_B		0x7
# define OPERATIONS_ROTATE_BOTH		0x8
# define OPERATIONS_RROTATE_A		0x9
# define OPERATIONS_RROTATE_B		0xa
# define OPERATIONS_RROTATE_BOTH	0xb
#endif // OPERATIONS_H
