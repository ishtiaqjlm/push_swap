/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_operation_rrotate.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:19 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 14:43:48 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <two_towers.h>
#include <libft.h>
#include <operations.h>

void	reverse_rotate_a(t_two_towers_ctx *ctx)
{
	ctx->statistics[OPERATIONS_RROTATE_A - 1]++;
	stack_rrotate(ctx->stack_a);
}

void	reverse_rotate_b(t_two_towers_ctx *ctx)
{
	ctx->statistics[OPERATIONS_RROTATE_B - 1]++;
	stack_rrotate(ctx->stack_b);
}

void	reverse_rotate_both(t_two_towers_ctx *ctx)
{
	ctx->statistics[OPERATIONS_RROTATE_BOTH - 1]++;
	stack_rrotate(ctx->stack_a);
	stack_rrotate(ctx->stack_b);
}
