/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:57 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 14:44:32 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <limits.h>

#include <stack.h>
#include <libft.h>

int	stack_initialize(t_stack **pstack, char *name)
{
	t_stack	*stack;
	size_t	dcapacity;
	size_t	n;
	int		*data;

	dcapacity = 16;
	if (dcapacity >= ((UINT_MAX - 1) / sizeof(int)))
		return (-1);
	stack = malloc(sizeof(t_stack));
	if (stack == NULL)
		return (-1);
	n = dcapacity * sizeof(int);
	data = malloc(n);
	if (data == NULL)
	{
		free(stack);
		return (-1);
	}
	ft_memset(data, 0, n);
	stack->name = name;
	stack->capacity = dcapacity;
	stack->top = (size_t) - 1;
	stack->data = data;
	*pstack = stack;
	return (0);
}

int	stack_finalize(t_stack **pstack)
{
	t_stack	*stack;

	stack = *pstack;
	free(stack->data);
	free(stack);
	return (0);
}

int	stack_push(t_stack *stack, t_stack_element *e)
{
	if (stack->top == stack->capacity)
		return (-1);
	stack->top++;
	stack->data[stack->top] = *e;
	return (0);
}

int	stack_pop(t_stack *stack, t_stack_element *e)
{
	t_stack_element	_e;

	if (stack->top == (size_t)-1)
		return (-1);
	_e = stack->data[stack->top];
	stack->top--;
	*e = _e;
	return (0);
}
