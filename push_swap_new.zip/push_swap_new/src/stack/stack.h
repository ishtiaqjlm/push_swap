/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:29:18 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 17:21:36 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STACK_H
# define STACK_H

typedef struct stack
{
	char	*name;
	size_t	capacity;
	size_t	top;	
	int		*data;
}	t_stack;

typedef int	t_stack_element;
typedef int	t_stack_rv;

int	stack_initialize(t_stack **pstack, char *name);
int	stack_finalize(t_stack **pstack);
int	stack_push(t_stack *stack, t_stack_element *e);
int	stack_pop(t_stack *stack, t_stack_element *e);
int	stack_swap(t_stack *stack);
int	stack_rotate(t_stack *stack);
int	stack_rrotate(t_stack *stack);
int	stack_print(t_stack *stack);
#endif // STACK_H
