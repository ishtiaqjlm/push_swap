/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algorithms.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:27:21 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 13:27:24 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ALGORITHMS_H
# define ALGORITHMS_H

void	minmax_sort(int *v, int n);
void	shell_sort(int *v, int n);
void	heap_sort(int *v, int n);
void	adaptive_sort(int *v, int n);

#endif	// ALGORITHMS_H
