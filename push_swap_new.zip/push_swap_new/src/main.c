#include "../includes/push_swap.h"
#include "../misc/two_towers.h"

int	main(int argc, char **argv)
{
	//test code for parsing arguments and numbers
    t_config	config;
	int			start;
	int			number;
	int			i;

	if (argc == 1)
		return (0);
	start = parse_args(argc, argv, &config);
	i = start;
	ft_printf("i is %i",i);
	(void) number;
	(void) config;
	/*while (i < argc)
	{
		if (parse_number(argv[i], &number) == 1)
		{
			write(2, "Error\n", 6);
			return (1);
		}
		else
		{

			write(1, "valid\n", 6);
		}
		
		i++;
	}*/
	return (0);
}

