/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:31:53 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 13:36:09 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

#include <stack.h>
#include <two_towers.h>
#include <libft.h>					// stubs to ft_* functions

int	two_towers_initialize(t_two_towers_ctx **pctx)
{
	t_two_towers_ctx	*ctx;
	t_stack				*stack_a;
	t_stack				*stack_b;

	*pctx = NULL;
	ctx = malloc(sizeof(t_two_towers_ctx));
	if (ctx == NULL)
		return (-1);
	if (stack_initialize(&stack_a, "a") == -1)
	{
		free(ctx);
		return (-1);
	}
	if (stack_initialize(&stack_b, "b") == -1)
	{
		stack_finalize(&stack_a);
		free(ctx);
		return (-1);
	}
	ctx->stack_a = stack_a;
	ctx->stack_b = stack_b;
	ft_memset(ctx->statistics, 0, 0x0b);
	*pctx = ctx;
	return (0);
}

int	two_towers_finalize(t_two_towers_ctx	**pctx)
{
	t_two_towers_ctx	*ctx;
	t_stack				*stack_a;
	t_stack				*stack_b;

	ctx = *pctx;
	stack_a = ctx->stack_a;
	stack_finalize(&stack_a);
	stack_b = ctx->stack_b;
	stack_finalize(&stack_b);
	free(ctx);
	*pctx = NULL;
	return (0);
}

int	two_towers_populate(t_two_towers_ctx **pctx, int *numbers, size_t nnumbers)
{
	size_t				i;
	int					e;
	t_stack				*stack_a;
	t_two_towers_ctx	*ctx;

	ctx = *pctx;
	stack_a = ctx->stack_a;
	i = 0;
	while (i < nnumbers)
	{
		e = numbers[i];
		stack_push(stack_a, &numbers[i]);
		i++;
	}
	return (0);
}
