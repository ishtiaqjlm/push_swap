/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   intvector.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:25:01 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/14 13:25:04 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	intvector_initialize(int **pv, size_t n);
int	intvector_finalize(int **pv, size_t n);
int	intvector_translate_from_stack(int *v, size_t n, t_stack *stack);
int	intvector_translate_to_stack(int *v, size_t n, t_stack *stack);
