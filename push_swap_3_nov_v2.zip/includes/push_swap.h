/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/07 13:23:34 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/11/03 15:18:54 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H
# include <stdlib.h>
# include <unistd.h>
# include <limits.h>

typedef struct s_node
{
	int				value;
	int				index;
	struct s_node	*next;
}	t_node;

typedef struct s_stack
{
	t_node	*top;
	int		size;
}	t_stack;

typedef enum e_strategy
{
	STRAT_ADAPTIVE,
	STRAT_SIMPLE,
	STRAT_MEDIUM,
	STRAT_COMPLEX
}	t_strategy;

typedef struct s_config
{
	t_strategy	strategy;
	int			bench;
	t_strategy	selected_strategy;
}	t_config;

typedef struct s_input_data
{
	int		start;
	int		*numbers;
	size_t	count;
	double	disorder;
}	t_input_data;
/* Parsing */
int		parse_args(int argc, char **argv, t_config *config);
int		parse_number(const char *str, int *number);
/* Validation */
int		duplicate_check(t_stack *stack);
#endif
