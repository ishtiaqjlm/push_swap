/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   strategy_runner.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/03 14:13:26 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/11/03 18:46:58 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <push_swap.h>
#include <two_towers.h>
#include <algorithms.h>

void	run_strategy(t_two_towers_ctx *ctx, t_config *config)
{
	if (config->strategy != STRAT_ADAPTIVE)
		config->selected_strategy = config->strategy;
	if (config->strategy == STRAT_SIMPLE)
		sort_simple(ctx);
	else if (config->strategy == STRAT_MEDIUM)
		sort_medium(ctx);
	else if (config->strategy == STRAT_COMPLEX)
		sort_complex(ctx);
	else
		sort_adaptive(ctx, config);
}
