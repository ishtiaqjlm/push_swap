/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aazubel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:31:45 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/03 16:23:27 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <two_towers.h>

int	main(int argc, char **argv)
{
	(void)argc;
	(void)argv;
	//ft_printf("hello two, you too, you tu, tower tu, tu tower, two tower s\n");
}
