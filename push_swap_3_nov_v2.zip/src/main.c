/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/02 16:37:09 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/03 14:54:11 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"
#include <two_towers.h>
#include <libft.h>
#include <stdlib.h>
#include <stddef.h>
#include <bench.h>
#include <algorithms.h>

static void	print_error(void)
{
	write(2, "Error\n", 6);
}

static int	load_numbers(int argc, char **argv, t_input_data *input)
{
	int	i;
	int	j;

	input->count = (size_t)(argc - input->start);
	input->numbers = malloc(sizeof(int) * input->count);
	if (input->numbers == NULL)
		return (0);
	i = 0;
	while (i < (int)input->count)
	{
		if (!parse_number(argv[input->start + i], &input->numbers[i]))
			return (free(input->numbers), input->numbers = NULL, 0);
		j = 0;
		while (j < i)
		{
			if (input->numbers[j] == input->numbers[i])
				return (free(input->numbers), input->numbers = NULL, 0);
			j++;
		}
		i++;
	}
	return (1);
}

static int	initialize_program(t_two_towers_ctx **ctx, t_input_data *input)
{
	if (two_towers_initialize(ctx) == -1)
		return (0);
	if (two_towers_populate(ctx, input->numbers, input->count) == -1)
	{
		two_towers_finalize(ctx);
		return (0);
	}
	return (1);
}

static void	execute_program(t_two_towers_ctx *ctx,
				t_config *config, t_input_data *input)
{
	input->disorder = stack_compute_disorder(ctx->stack_a);
	run_strategy(ctx, config);
	if (config->bench)
		run_bench(ctx, config, input->disorder);
}

int	main(int argc, char **argv)
{
	t_config			config;
	t_two_towers_ctx	*ctx;
	t_input_data		input;

	if (argc == 1)
		return (0);
	input.start = parse_args(argc, argv, &config);
	if (input.start < 0)
		return (print_error(), 1);
	if (input.start >= argc)
		return (0);
	if (!load_numbers(argc, argv, &input))
		return (print_error(), 1);
	if (!initialize_program(&ctx, &input))
		return (free(input.numbers), print_error(), 1);
	free(input.numbers);
	execute_program(ctx, &config, &input);
	two_towers_finalize(&ctx);
	return (0);
}
