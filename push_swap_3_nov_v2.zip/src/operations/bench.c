/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bench.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/02 15:06:39 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/03 18:55:33 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <push_swap.h>
#include <algorithms.h>
#include <bench.h>
#include <libft.h>
#include <operations.h>

static void	print_strategy(t_config *config)
{
	write(2, "[bench] strategy:  ", 19);
	if (config->selected_strategy == STRAT_SIMPLE)
		write(2, "Simple / O(n²)\n",
			sizeof("Simple / O(n²)\n"));
	else if (config->selected_strategy == STRAT_MEDIUM)
		write(2, "Medium / O(n√n)\n", 18);
	else if (config->selected_strategy == STRAT_COMPLEX)
		write(2, "Complex / O(n log n)\n", 22);
	else
		write(2, "Adaptive / O(n√n)\n", 20);
}

static void	print_disorder(double disorder)
{
	int	value;

	value = (int)(disorder * 10000 + 0.5);
	write(2, "[bench] disorder: ", 18);
	ft_putnbr_fd(value / 100, 2);
	write(2, ".", 1);
	if (value % 100 < 10)
		write(2, "0", 1);
	ft_putnbr_fd(value % 100, 2);
	write(2, "%\n", 2);
}

static void	print_total_operation(t_two_towers_ctx *ctx)
{
	size_t	total;

	total = 0;
	total += ctx->statistics[OPERATIONS_SWAP_A - 1];
	total += ctx->statistics[OPERATIONS_SWAP_B - 1];
	total += ctx->statistics[OPERATIONS_SWAP_BOTH - 1];
	total += ctx->statistics[OPERATIONS_PUSH_A - 1];
	total += ctx->statistics[OPERATIONS_PUSH_B - 1];
	total += ctx->statistics[OPERATIONS_ROTATE_A - 1];
	total += ctx->statistics[OPERATIONS_ROTATE_B - 1];
	total += ctx->statistics[OPERATIONS_ROTATE_BOTH - 1];
	total += ctx->statistics[OPERATIONS_RROTATE_A - 1];
	total += ctx->statistics[OPERATIONS_RROTATE_B - 1];
	total += ctx->statistics[OPERATIONS_RROTATE_BOTH - 1];
	write(2, "[bench] total_ops: ", 19);
	ft_putnbr_fd((int)total, 2);
	write(2, "\n", 1);
}

void	run_bench(t_two_towers_ctx *ctx, t_config *config, double disorder)
{
	print_disorder(disorder);
	print_strategy(config);
	print_total_operation(ctx);
	print_detail_operation(ctx);
}
