/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rank_utils.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/27 11:10:41 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/11/03 18:05:15 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stack.h>
#include <algorithms.h>

static size_t	get_rank(int *values, size_t n, size_t index)
{
	size_t	j;
	size_t	rank;

	rank = 0;
	j = 0;
	while (j < n)
	{
		if (values[j] < values[index])
			rank++;
		j++;
	}
	return (rank);
}

static void	calculate_ranks(int *values, int *ranks, size_t n)
{
	size_t	i;

	i = 0;
	while (i < n)
	{
		ranks[i] = (int)get_rank(values, n, i);
		i++;
	}
}

static void	copy_values(int *dest, int *src, size_t n)
{
	size_t	i;

	i = 0;
	while (i < n)
	{
		dest[i] = src[i];
		i++;
	}
}

int	normalize_ranks(t_array_stack *stack)
{
	size_t	n;
	int		*values;
	int		*ranks;

	if (stack->top == (size_t)-1)
		return (0);
	n = stack->top + 1;
	values = malloc(sizeof(int) * n);
	ranks = malloc(sizeof(int) * n);
	if (!values || !ranks)
		return (free(values), free(ranks), -1);
	copy_values(values, stack->data, n);
	calculate_ranks(values, ranks, n);
	copy_values(stack->data, ranks, n);
	free(values);
	free(ranks);
	return (0);
}
