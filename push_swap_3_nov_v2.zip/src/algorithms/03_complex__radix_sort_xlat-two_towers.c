/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   03_complex__radix_sort_xlat-two_towers.c           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/30 15:11:50 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/03 16:30:33 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>		// malloc
#include <two_towers.h>
#include <algorithms.h>
#include <unistd.h>
#include <libft.h>

int	_xlat_initialize(
		t_two_towers_ctx *ctx, size_t n, long int **pzsubset)
{
	size_t		i;
	long int	*zsubset;

	zsubset = malloc(sizeof(long int) * n);
	if (zsubset == NULL)
		return (-1);
	i = 0;
	while (i < n)
	{
		zsubset[i] = ctx->stack_a->data[i];
		i++;
	}
	*pzsubset = zsubset;
	return (0);
}

int	_xlat_reorder(size_t *xlat_table, long int *zsubset, size_t n)
{
	size_t		i;
	size_t		j;
	size_t		k;
	long int	m;

	i = 0;
	while (i < n)
	{
		k = 0;
		m = zsubset[0];
		j = 1;
		while (j < n)
		{
			if (zsubset[j] < m)
			{
				m = zsubset[j];
				k = j;
			}
			j++;
		}
		xlat_table[i] = (size_t)m;
		zsubset[k] = 2147483648L;
		i++;
	}
	return (0);
}

int	_xlat_finalize(long int	*zsubset, size_t n)
{
	(void)n;
	free(zsubset);
	return (0);
}

// integer numbers can be mapped to non-negative integers
// => "normalizing" its representation
// (a bijection from integers / Z to nonnegative integers / Z{0+})
void	init_xlat_from_zsubset_to_nonnegative_integers(
	t_two_towers_ctx *ctx,
	size_t *xlat_table,
	size_t xlat_table_length)
{
	size_t		n;
	long int	*zsubset;

	n = xlat_table_length;
	if (_xlat_initialize(ctx, n, &zsubset) == -1)
		return ;
	_xlat_reorder(xlat_table, zsubset, n);
	_xlat_finalize(zsubset, n);
}

size_t	xlat_from_zsubset_to_nonnegative_integers(
	size_t x,
	size_t *xlat_table,
	size_t xlat_table_length)
{
	size_t	i;

	i = 0;
	while (i < xlat_table_length)
	{
		if (xlat_table[i] == x)
			return (i);
		i++;
	}
	return ((size_t)-1);
}
