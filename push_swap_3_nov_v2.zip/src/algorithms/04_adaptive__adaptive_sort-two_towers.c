/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   04_adaptive__adaptive_sort-two_towers.c            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:27:10 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/03 18:43:44 by aazubel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <two_towers.h>
#include <algorithms.h>

int	inspection_sort(t_two_towers_ctx *ctx, t_config *config)
{
	size_t	n;

	if (ctx->stack_a->top == (size_t)-1)
		return (-1);
	n = ctx->stack_a->top + 1;
	if (n > 3)
		return (1);
	config->selected_strategy = STRAT_SIMPLE;
	if (n <= 1)
		return (0);
	if (n == 2)
		sort_two(ctx);
	if (n == 3)
		sort_three(ctx);
	return (0);
}

void	two_towers_adaptive_sort(t_two_towers_ctx *ctx, t_config *config)
{
	double	disorder;

	config->selected_strategy = STRAT_SIMPLE;
	if (inspection_sort(ctx, config) <= 0)
		return ;
	disorder = stack_compute_disorder(ctx->stack_a);
	if (disorder <= 0.0)
		return ;
	if (disorder < 0.2)
	{
		config->selected_strategy = STRAT_SIMPLE;
		sort_simple(ctx);
	}
	else if (disorder < 0.5)
	{
		config->selected_strategy = STRAT_MEDIUM;
		sort_medium(ctx);
	}
	else
	{
		config->selected_strategy = STRAT_COMPLEX;
		two_towers_radix_sort(ctx);
	}
}
