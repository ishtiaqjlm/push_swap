*This project has been created as part of the 42 curriculum by ishtiahm, aazubel.*

# Push_swap

## Description

Push_swap is a sorting algorithm project from the 42 curriculum.

The objective is to sort a collection of unique integers in ascending order using two stacks, named `a` and `b`, and a restricted set of stack operations.

Initially:
- Stack A contains the input integers.
- Stack B is empty.

The program must generate a sequence of valid operations that sorts Stack A in ascending order while minimizing the total number of operations.

This project implements three sorting strategies and an adaptive strategy that selects an algorithm according to the disorder of the input.

## Instructions

### Requirements

- GCC or another compatible C compiler.
- Make.
- Linux or a compatible Unix environment.
- The 42 `checker` program for validating operations.
- Valgrind (optional, for memory testing).

### Compilation

Clone the repository:

```bash
git clone git@vogsphere.42prague.com:vogsphere/intra-uuid-81cac29c-6093-4444-9331-c968012d93c1-7720587-aazubel
cd push_swap
```

Compile the project:

```bash
make
```

Clean object files:

```bash
make clean
```

Remove object files and the executable:

```bash
make fclean
```

Recompile from scratch:

```bash
make re
```

### Execution

Default execution uses the Adaptive strategy:

```bash
./push_swap 4 2 7 1 3
```

Choose a specific sorting strategy:

```bash
./push_swap --simple 4 2 7 1 3
./push_swap --medium 4 2 7 1 3
./push_swap --complex 4 2 7 1 3
./push_swap --adaptive 4 2 7 1 3
```

### Benchmark mode

Use `--bench` to display performance information:

```bash
./push_swap --bench --adaptive 4 2 7 1 3
```

The benchmark is printed to standard error, while sorting operations are printed to standard output.

Benchmark information includes:
- Input disorder percentage.
- Selected sorting strategy.
- Algorithmic complexity.
- Total number of operations.
- Individual operation counts.

Separate the output streams:

```bash
./push_swap --bench --adaptive 4 2 7 1 3 \
    > operations.txt 2> benchmark.txt
```

### Checking the result

Use the 42 checker to verify the generated operations:

```bash
./push_swap 4 2 7 1 3 | ./checker 4 2 7 1 3
```

Expected output:

```text
OK
```

You can also check saved operations:

```bash
./checker 4 2 7 1 3 < operations.txt
```

## Available Operations

The project uses the following operations:

| Operation | Description |
|---|---|
| `sa` | Swap the first two elements of Stack A |
| `sb` | Swap the first two elements of Stack B |
| `ss` | Perform `sa` and `sb` simultaneously |
| `pa` | Push the top element of B onto A |
| `pb` | Push the top element of A onto B |
| `ra` | Rotate Stack A upwards |
| `rb` | Rotate Stack B upwards |
| `rr` | Perform `ra` and `rb` simultaneously |
| `rra` | Reverse rotate Stack A |
| `rrb` | Reverse rotate Stack B |
| `rrr` | Perform `rra` and `rrb` simultaneously |

## Algorithms and Technical Choices

This project implements three sorting algorithms and one adaptive strategy.

### 1. Simple Strategy — O(n²)

The Simple strategy uses a selection-based approach.

The algorithm repeatedly:
1. Finds the minimum element in Stack A.
2. Rotates Stack A to bring the minimum element to the top.
3. Pushes the minimum element to Stack B.
4. Repeats until Stack A is empty.
5. Pushes all elements back from Stack B to Stack A.

Since the minimum element is pushed first, it is eventually placed at the bottom of Stack A. The resulting stack is sorted in ascending order from top to bottom.

This approach is straightforward and suitable for smaller inputs, but its operation count grows considerably with larger collections.

### 2. Medium Strategy — O(n√n)

The Medium strategy uses a range-based chunking approach.

The algorithm:
1. Normalizes the input values into ranks from `0` to `n - 1`.
2. Divides the rank range into smaller chunks.
3. Searches Stack A for elements belonging to the current chunk.
4. Pushes matching elements to Stack B.
5. Uses rotations to organize elements in Stack B.
6. Reconstructs Stack A by repeatedly finding and bringing the maximum element in Stack B to its top, then pushing it back to Stack A.

The reconstruction phase uses both forward and reverse rotations to reduce unnecessary operations.

The range-based approach is designed to achieve O(n√n) algorithmic complexity.

### 3. Complex Strategy — O(n log n)

The Complex strategy uses a binary radix sort approach.

The algorithm:
1. Normalizes the input values into non-negative ranks.
2. Examines the binary representation of each rank, one bit at a time.
3. Pushes elements with a `0` in the current bit position from Stack A to Stack B.
4. Rotates elements with a `1` in the current bit position within Stack A.
5. Pushes elements back from Stack B to Stack A.
6. Repeats the process for all significant bits.

After processing all relevant bits, the elements are sorted in ascending order.

Radix sort provides O(n log n) algorithmic complexity for the rank-based sorting process.

### 4. Adaptive Strategy

The Adaptive strategy selects a sorting algorithm based on the initial disorder of the input.

Disorder is calculated using the number of inversions in the input sequence.

An inversion is a pair of elements where an earlier element is greater than a later element.

The disorder percentage is calculated as:

```text
Disorder = inversions / total possible pairs
```

The strategy selection uses the following thresholds:

| Disorder | Selected strategy |
|---|---|
| Below 20% | Simple |
| 20% to below 50% | Medium |
| 50% or above | Complex |

Small inputs are handled separately:
- Empty or single-element inputs require no operations.
- Two-element inputs use `sort_two`.
- Three-element inputs use `sort_three`.

The Adaptive strategy aims to select an appropriate algorithm according to the initial arrangement of the input rather than always using the same sorting method.

## Performance Benchmarks

The project is evaluated using operation counts for randomly generated inputs.

The required performance targets are:

| Input size | Minimum requirement | Good performance | Excellent performance |
|---|---:|---:|---:|
| 100 numbers | Below 2,000 | Below 1,500 | Below 700 |
| 500 numbers | Below 12,000 | Below 8,000 | Below 5,500 |

The benchmark mode reports the selected strategy, disorder percentage, total operations, and individual operation counts.

## Error Handling

The program validates input arguments and rejects:
- Non-numeric arguments.
- Duplicate integers.
- Values outside the signed integer range.
- Invalid strategy options.

Invalid input produces:

```text
Error
```

## Team Contributions

This project was developed collaboratively by two students.

### [ishtiahm] — Ishtiaq Ahmed

Contributions:
- [Describe your implemented modules and functions.]
- [Describe your sorting algorithm contributions.]
- [Describe your parsing, stack, or benchmark contributions.]
- [Describe your testing and debugging contributions.]

### [aazubel] — Augustin Azubel 

Contributions:
- [Describe the teammate's implemented modules and functions.]
- [Describe their sorting algorithm contributions.]
- [Describe their testing and debugging contributions.]

### Collaborative Work

Both team members participated in:
- Project architecture and algorithm discussions.
- Integration and debugging.
- Testing and validation.
- Code review and preparation for the project defence.

## Resources

The following resources were used to understand the algorithms, C programming concepts, and project requirements:

- [42 School — Push_swap subject](https://cdn.intra.42.fr/pdf/pdf/123456/en.subject.pdf) — Project requirements and permitted operations. Replace this link with the official subject link if necessary.
- [CP-Algorithms — Radix Sort](https://cp-algorithms.com/sorting/radix-sort.html) — Reference for radix sorting.
- [GeeksforGeeks — Selection Sort](https://www.geeksforgeeks.org/dsa/selection-sort-algorithm-2/) — Reference for selection-based sorting.
- [Big-O Cheat Sheet](https://www.bigocheatsheet.com/) — Reference for algorithmic complexity.
- [GNU GCC Documentation](https://gcc.gnu.org/onlinedocs/) — Compiler documentation.
- [Valgrind Documentation](https://valgrind.org/docs/manual/manual.html) — Memory debugging and leak detection.

### AI Usage

AI tools, including ChatGPT, were used as supporting tools during development and learning.

Their usage included:
- Supporting debugging and the interpretation of benchmark results.
- Reviewing README documentation and improving technical explanations.

AI-generated suggestions were reviewed, tested, and adapted by the team. The team members remain responsible for understanding, implementing, testing, and defending the final code.