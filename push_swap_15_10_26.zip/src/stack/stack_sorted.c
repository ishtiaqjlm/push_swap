/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_sorted.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/15 01:36:19 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/10/15 01:36:19 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include <stack.h>
#include <unistd.h>

int	stack_is_sorted(t_array_stack *stack)
{
	size_t	i;

	if (stack->top == (size_t)-1 || stack->top == 0)
		return (1);
	i = stack->top;
	while (i > 0)
	{
		if (stack->data[i] > stack->data[i - 1])
			return (0);
		i--;
	}
	return (1);
}

int	stack_print(t_array_stack *stack)
{
	size_t	i;
	char	buffer[12];
	int		n;
	int		value;

	i = stack->top;
	while (i != (size_t)-1)
	{
		value = stack->data[i];
		n = 0;
		if (value < 0)
		{
			write(1, "-", 1);
			value = -value;
		}
		if (value == 0)
			buffer[n++] = '0';
		while (value > 0)
		{
			buffer[n++] = '0' + value % 10;
			value /= 10;
		}
		while (n > 0)
			write(1, &buffer[--n], 1);
		write(1, "\n", 1);
		if (i == 0)
			break ;
		i--;
	}
	return (0);
}

