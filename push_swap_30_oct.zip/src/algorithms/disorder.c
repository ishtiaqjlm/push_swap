/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   disorder.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/29 16:49:32 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/10/30 17:12:56 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <algorithms.h>

static size_t	count_inversions(int *v, size_t n)
{
	size_t	i;
	size_t	j;
	size_t	mistakes;

	mistakes = 0;
	i = 0;
	while (i < n - 1)
	{
		j = i + 1;
		while (j < n)
		{
			if (v[i] > v[j])
				mistakes++;
			j++;
		}
		i++;
	}
	return (mistakes);
}

double	compute_disorder(t_two_towers_ctx *ctx)
{
	size_t	n;
	size_t	total_pairs;
	size_t	mistakes;

	n = ctx->stack_a->top + 1;
	total_pairs = n * (n - 1) / 2;
	if (total_pairs == 0)
		return (0.0);
	mistakes = count_inversions(ctx->stack_a->data, n);
	//printf(stderr, "Inversions: %zu\n", mistakes);
    //printf(stderr, "Total pairs: %zu\n", total_pairs);
    //printf(stderr, "Disorder: %.3f\n", disorder);
	return ((double)mistakes / (double)total_pairs);
}
