/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   03_complex__radix_sort_xlat-two_towers.c           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/30 15:11:50 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/30 16:43:15 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>      // XXX
#include <stdlib.h>		// malloc 
#include <two_towers.h>
#include <algorithms.h>

int	_xlat_initialize(
		t_two_towers_ctx *ctx, size_t n, long int **pzsubset)
{
	size_t		i;
	long int	*zsubset;

	zsubset = malloc(sizeof(long int) * n);
	if (*pzsubset == NULL)
		return (-1);
	i = 0;
	while (i < n)
	{
		zsubset[i] = ctx->stack_a->data[i];
		i++;
	}
	*pzsubset = zsubset;
	return (0);
}

int	_xlat_reorder(
		t_two_towers_ctx *ctx, size_t *xlat_table, long int *zsubset, size_t n)
{
	size_t		i;
	size_t		j;
	size_t		k;
	int			m;

	i = 0;
	while (i < n)
	{
		k = 0;
		m = ctx->stack_a->data[0];
		j = 1;
		while (j < n)
		{
			if (zsubset[j] < m)
			{
				m = zsubset[j];
				k = j;
			}
			j++;
		}
		xlat_table[i] = m;
		zsubset[k] = 2147483647L + 1;
		i++;
	}
	return (0);
}

/*
int	_xlat_finalize(long int	*zsubset, size_t n)
{
	size_t	i;

	i = 0;
	while (i < n)
	{
//		xlat_table[i] = zsubset[i];
//		printf("|\t\t\t\t%zu\n", xlat_table[i]);
		i++;
	}
	free(zsubset);
	return (0);
}
*/

int	_xlat_finalize(long int	*zsubset, size_t n)
{
	(void)n;
	free(zsubset);
	return (0);
}

// integer numbers can be mapped to non-negative integers
// => "normalizing" its representation
// (a bijection from integers / Z to nonnegative integers / Z{0+})
void	init_xlat_from_zsubset_to_nonnegative_integers(
	t_two_towers_ctx *ctx,
	size_t *xlat_table,
	size_t xlat_table_length)
{
	size_t		n;
	long int	*zsubset;

	n = xlat_table_length;
	_xlat_initialize(ctx, n, &zsubset);
	_xlat_reorder(ctx, xlat_table, zsubset, n);
	_xlat_finalize(zsubset, n);
}

size_t	xlat_from_zsubset_to_nonnegative_integers(
	size_t x,
	size_t *xlat_table,
	size_t xlat_table_length)
{
	size_t	i;

	i = 0;
	while (i < xlat_table_length)
	{
		if (xlat_table[i] == x)
			return (i);
		i++;
	}
	return ((size_t)-1);
}
