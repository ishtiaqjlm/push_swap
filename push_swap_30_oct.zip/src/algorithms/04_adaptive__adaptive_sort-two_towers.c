/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   04_adaptive__adaptive_sort-two_towers.c            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:27:10 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/30 17:21:12 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <two_towers.h>
#include <algorithms.h>

void	two_towers_adaptive_sort(t_two_towers_ctx *ctx)
{
	double	disorder;

	if (ctx->stack_a->top == (size_t)-1)
		return ;
	disorder = compute_disorder(ctx);
	//ft_printf(stderr, "Disorder: %.3f\n", disorder);
	if (disorder == 0.0)
		return ;
	if (disorder < 0.2)
	{
		//ft_printf(stderr, "Selected: simple\n");
		sort_simple(ctx);
	}
	else if (disorder < 0.5)
	{
		//ft_printf(stderr, "Selected: medium\n");
		sort_medium(ctx);
	}
	else
	{
		//ft_printf(stderr, "Selected: complex\n");
		two_towers_radix_sort(ctx);
	}
}
