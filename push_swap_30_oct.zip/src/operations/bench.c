
#include <stdio.h>
#include <unistd.h>
#include <push_swap.h>
#include <algorithms.h>
#include <bench.h>

static void	print_strategy(t_two_towers_ctx *ctx, t_config *config)
{
	
	(void)ctx;
	if (config->strategy == STRAT_SIMPLE)
        write(2, "SIMPLE\n", 7);
    else if (config->strategy == STRAT_MEDIUM)
        write(2, "MEDIUM\n", 7);
    else if (config->strategy == STRAT_COMPLEX)
        write(2, "COMPLEX\n", 8);
    else
        write(2, "ADAPTIVE\n", 9);
}

static void	print_disorder(t_two_towers_ctx *ctx, t_config *config)
{
	printf("disorder: %.2f%%\n", compute_disorder(ctx));
	(void)config;
}

static void print_total_operation(t_two_towers_ctx *ctx, t_config *config)
{
	(void)ctx;
	(void)config;

}

static void print_detail_operation(t_two_towers_ctx *ctx, t_config *config)
{

	(void)ctx;
	(void)config;
}

void	run_bench(t_two_towers_ctx *ctx, t_config *config)
{
	print_disorder(ctx, config);
	print_strategy(ctx, config);
	print_total_operation(ctx, config);
	print_detail_operation(ctx, config);
}