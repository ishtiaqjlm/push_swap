/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:28:30 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/30 19:21:58 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef OPERATIONS_H

#include <two_towers.h>
#include <push_swap.h>

# define OPERATIONS_H
# define OPERATIONS_SWAP_A 			0x1
# define OPERATIONS_SWAP_B 			0x2
# define OPERATIONS_SWAP_BOTH		0x3
# define OPERATIONS_PUSH_A 			0x4
# define OPERATIONS_PUSH_B 			0x5
# define OPERATIONS_ROTATE_A		0x6
# define OPERATIONS_ROTATE_B		0x7
# define OPERATIONS_ROTATE_BOTH		0x8
# define OPERATIONS_RROTATE_A		0x9
# define OPERATIONS_RROTATE_B		0xa
# define OPERATIONS_RROTATE_BOTH	0xb
void    operation_output(const char *operation);
void	run_bench(t_two_towers_ctx *ctx, t_config *config);
#endif // OPERATIONS_H
