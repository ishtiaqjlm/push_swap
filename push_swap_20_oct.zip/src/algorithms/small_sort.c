/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   small_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/20 15:22:00 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/10/20 18:22:11 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <two_towers.h>

void    sort_two(t_two_towers_ctx *ctx)
{
	int first;
	int second;

	first = ctx->stack_a->data[ctx->stack_a->top];
	second = ctx->stack_a->data[ctx->stack_a->top - 1];
	if (first > second)
		swap_a(ctx);
}

void    sort_three(t_two_towers_ctx *ctx)
{
	int first;
	int second;
	int third;

	first = ctx->stack_a->data[ctx->stack_a->top];
	second = ctx->stack_a->data[ctx->stack_a->top - 1];
	third = ctx->stack_a->data[ctx->stack_a->top - 2];
	if (first > second && second < third && first < third)
		swap_a(ctx);
	else if (first > second && second > third)
	{
		swap_a(ctx);
		reverse_rotate_a(ctx);
	}
	else if (first > second && second < third && first > third)
		rotate_a(ctx);
	else if (first < second && second > third && first < third)
	{
		swap_a(ctx);
		rotate_a(ctx);
	}
	else if (first < second && second > third && first > third)
		reverse_rotate_a(ctx);
}

static size_t	find_min_position(t_array_stack *stack)
{
	size_t  i;
	size_t  min_pos;

	i = stack->top;
	min_pos = i;
	while (i > 0)
	{
		i--;
		if (stack->data[i] < stack->data[min_pos])
			min_pos = i;
	}
	return (min_pos);
}

void	test_find_min_position(t_two_towers_ctx *ctx)
{
	size_t  pos;

	pos = find_min_position(ctx->stack_a);
}

void	sort_simple_general(t_two_towers_ctx *ctx)
{
	(void)ctx;
}
