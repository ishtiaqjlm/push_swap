
import random
import subprocess
import re
import sys

PUSH_SWAP = "./push_swap"
CHECKER = "./checker_linux"

def expected_strategy(values):
    n = len(values)
    pairs = n * (n - 1) // 2

    if pairs == 0:
        return None

    inversions = sum(
        values[i] > values[j]
        for i in range(n)
        for j in range(i + 1, n)
    )

    disorder = inversions / pairs

    if disorder == 0 or disorder < 0.2:
        return "Simple"
    elif disorder < 0.5:
        return "Medium"
    return "Complex"


def test_case(values):
    args = [PUSH_SWAP, "--bench", "--adaptive"]
    args += [str(x) for x in values]

    result = subprocess.run(
        args,
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        print("FAIL: push_swap execution error:", values)
        print(result.stderr)
        return False

    # Validate operations with checker
    checker = subprocess.run(
        [CHECKER] + [str(x) for x in values],
        input=result.stdout,
        capture_output=True,
        text=True
    )

    if checker.stdout.strip() != "OK":
        print("FAIL: checker returned:", checker.stdout.strip())
        print("Input:", values)
        print("Operations:\n", result.stdout)
        return False

    # Validate adaptive strategy selection
    expected = expected_strategy(values)

    if expected is not None:
        match = re.search(
            r"\[bench\] strategy:\s*(Simple|Medium|Complex)",
            result.stderr
        )

        if not match:
            print("FAIL: strategy not reported correctly:", values)
            print(result.stderr)
            return False

        actual = match.group(1)

        if actual != expected:
            print("FAIL: incorrect adaptive strategy")
            print("Input:", values)
            print("Expected:", expected)
            print("Actual:", actual)
            print(result.stderr)
            return False

    return True


def main():
    passed = 0
    failed = 0

    # Small deterministic tests
    tests = [
        [1],
        [1, 2],
        [2, 1],
        [1, 3, 2, 4, 5],
        [5, 4, 3, 2, 1],
        [-5, 3, 0, -2, 8, 1],
    ]

    # Random tests with different input sizes
    random.seed(42)

    for size in [5, 10, 50, 100, 500]:
        for _ in range(20):
            values = random.sample(range(-10000, 10001), size)
            tests.append(values)

    for values in tests:
        if test_case(values):
            passed += 1
        else:
            failed += 1

    print("\n========== ADAPTIVE TEST RESULTS ==========")
    print("Passed:", passed)
    print("Failed:", failed)
    print("Total:", passed + failed)

    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
