/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/02 16:37:09 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 23:37:52 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"
#include <two_towers.h>
#include <libft.h>
#include <stdlib.h>
#include <stddef.h>
#include <bench.h>
#include <algorithms.h>

static void	print_error(void)
{
	write(2, "Error\n", 6);
}

static void	run_strategy(t_two_towers_ctx *ctx, t_config *config)
{
	if (config->strategy == STRAT_SIMPLE)
		sort_simple(ctx);
	else if (config->strategy == STRAT_MEDIUM)
		sort_medium(ctx);
	else if (config->strategy == STRAT_COMPLEX)
		sort_complex(ctx);
	else
		sort_adaptive(ctx, config);
}

static int	load_numbers(int argc, char **argv, int start,
				int **numbers, size_t *count)
{
	int		i;
	int		j;

	*count = (size_t)(argc - start);
	*numbers = malloc(sizeof(int) * *count);
	if (*numbers == NULL)
		return (0);
	i = 0;
	while (i < (int)*count)
	{
		if (!parse_number(argv[start + i], &(*numbers)[i]))
			return (free(*numbers), *numbers = NULL, 0);
		j = 0;
		while (j < i)
		{
			if ((*numbers)[j] == (*numbers)[i])
				return (free(*numbers), *numbers = NULL, 0);
			j++;
		}
		i++;
	}
	return (1);
}

int	main(int argc, char **argv)
{
	t_config			config;
	t_two_towers_ctx	*ctx;
	int					start;
	int					*numbers;
	size_t				count;
	double				disorder;

	if (argc == 1)
		return (0);
	start = parse_args(argc, argv, &config);
	if (start < 0)
		return (print_error(), 1);
	if (start >= argc)
		return (0);
	if (!load_numbers(argc, argv, start, &numbers, &count))
		return (print_error(), 1);
	if (two_towers_initialize(&ctx) == -1)
		return (free(numbers), print_error(), 1);
	if (two_towers_populate(&ctx, numbers, count) == -1)
		return (free(numbers), two_towers_finalize(&ctx),
			print_error(), 1);
	free(numbers);
	disorder = stack_compute_disorder(ctx->stack_a);
	run_strategy(ctx, &config);
	if (config.bench)
		run_bench(ctx, &config, disorder);
	two_towers_finalize(&ctx);
	return (0);
}
