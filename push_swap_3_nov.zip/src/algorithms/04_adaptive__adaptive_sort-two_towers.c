/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   04_adaptive__adaptive_sort-two_towers.c            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:27:10 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 23:44:03 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <two_towers.h>
#include <algorithms.h>

void	two_towers_adaptive_sort(t_two_towers_ctx *ctx, t_config *config)
{
	double	disorder;

	if (ctx->stack_a->top == (size_t)-1)
		return ;
	disorder = stack_compute_disorder(ctx->stack_a);
	if (disorder < 0.0)
        return ;
	if (disorder == 0.0)
		return ;
	if (disorder < 0.2)
	{
		config->selected_strategy = STRAT_SIMPLE;
		sort_simple(ctx);
	}
	else if (disorder < 0.5)
	{
		config->selected_strategy = STRAT_MEDIUM;
		sort_medium(ctx);
	}
	else
	{
		config->selected_strategy = STRAT_COMPLEX;
		two_towers_radix_sort(ctx);
	}

}
