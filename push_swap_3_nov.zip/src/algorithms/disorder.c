/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   disorder.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/29 16:49:32 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/11/03 00:03:34 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

	#include <algorithms.h>
	#include <stdlib.h>		// malloc
	#include <unistd.h>
	#include <libft.h>

	static size_t	count_inversions(int *v, size_t n)
	{
		size_t	i;
		size_t	j;
		size_t	mistakes;

		mistakes = 0;
		i = 0;
		while (i < n - 1)
		{
			j = i + 1;
			while (j < n)
			{
				if (v[i] > v[j])
					mistakes++;
				j++;
			}
			i++;
		}
		return (mistakes);
	}

	static double	compute_disorder(int *v, size_t n)
	{
		size_t	total_pairs;
		size_t	mistakes;

		total_pairs = n * (n - 1) / 2;
		if (total_pairs == 0)
			return (0.0);
		mistakes = count_inversions(v, n);
		return ((double)mistakes / (double)total_pairs);
	}

	double stack_compute_disorder(t_array_stack *stack)
	{
		int     *vector;
		size_t  n;
		size_t  i;
		double  disorder;

		if (stack->top == (size_t)-1)
			return (0.0);
		n = stack->top + 1;
		vector = malloc(sizeof(int) * n);
		if (vector == NULL)
			return (-1.0);
		i = 0;
		while (i < n)
		{
			vector[i] = stack->data[stack->top - i];
			i++;
		}
		disorder = compute_disorder(vector, n);
		free(vector);
		return (disorder);
	}
