/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_algorithms.h                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:32:30 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 23:33:36 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TWO_TOWERS_ALGORITHMS_H
# define TWO_TOWERS_ALGORITHMS_H

void	sort_simple(t_two_towers_ctx *ctx);
void	sort_medium(t_two_towers_ctx *ctx);
void	sort_complex(t_two_towers_ctx *ctx);
void	sort_adaptive(t_two_towers_ctx *ctx, t_config *config);
#endif	//TWO_TOWERS_ALGORITHMS_H
