/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   two_towers_algorithms.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:31:49 by aazubel           #+#    #+#             */
/*   Updated: 2026/11/02 23:34:11 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <two_towers.h>
#include <libft.h>
#include <algorithms.h>
#include <push_swap.h>
#include <unistd.h>

void	sort_simple(t_two_towers_ctx *ctx)
{
	size_t	n;

	if (ctx->stack_a->top == (size_t)-1)
		return ;
	n = ctx->stack_a->top + 1;
	if (n <= 1)
		return ;
	else if (n == 2)
		sort_two(ctx);
	else if (n == 3)
		sort_three(ctx);
	else
		sort_simple_general(ctx);
}

void	sort_complex(t_two_towers_ctx *ctx)
{
	two_towers_radix_sort(ctx);
}

void	sort_adaptive(t_two_towers_ctx *ctx, t_config *config)
{
	two_towers_adaptive_sort(ctx, config);
}
