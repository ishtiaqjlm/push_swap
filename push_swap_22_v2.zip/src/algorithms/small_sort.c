/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   small_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/20 15:22:00 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/10/22 02:01:08 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <two_towers.h>
#include <operations.h>
#include <stack.h>

void	sort_two(t_two_towers_ctx *ctx)
{
	int first;
	int second;

	first = ctx->stack_a->data[ctx->stack_a->top];
	second = ctx->stack_a->data[ctx->stack_a->top - 1];
	if (first > second)
		swap_a(ctx);
}

void	sort_three(t_two_towers_ctx *ctx)
{
	int first;
	int second;
	int third;

	first = ctx->stack_a->data[ctx->stack_a->top];
	second = ctx->stack_a->data[ctx->stack_a->top - 1];
	third = ctx->stack_a->data[ctx->stack_a->top - 2];
	if (first > second && second < third && first < third)
		swap_a(ctx);
	else if (first > second && second > third)
	{
		swap_a(ctx);
		reverse_rotate_a(ctx);
	}
	else if (first > second && second < third && first > third)
		rotate_a(ctx);
	else if (first < second && second > third && first < third)
	{
		swap_a(ctx);
		rotate_a(ctx);
	}
	else if (first < second && second > third && first > third)
		reverse_rotate_a(ctx);
}

static int is_sorted(t_array_stack *stack)
{
    size_t i;

    if (stack->top == (size_t)-1)
        return (1);
    i = stack->top;
    while (i > 0)
    {
        if (stack->data[i] > stack->data[i - 1])
            return (0);
        i--;
    }
    return (1);
}

static size_t	find_min_position(t_array_stack *stack)
{
	size_t  i;
	size_t  min_pos;

	i = stack->top;
	min_pos = i;
	while (i > 0)
	{
		i--;
		if (stack->data[i] < stack->data[min_pos])
			min_pos = i;
	}
	return (min_pos);
}

static void rotate_min_to_top(t_two_towers_ctx *ctx, size_t min_pos)
{
	size_t  forward;
	size_t  reverse;
	size_t  top;

	top = ctx->stack_a->top;
	forward = top - min_pos;
	reverse = min_pos + 1;
	if (forward <= reverse)
	{
		while (forward-- > 0)
			rotate_a(ctx);
	}
	else
	{
		while (reverse-- > 0)
			reverse_rotate_a(ctx);
	}
}

void	sort_simple_general(t_two_towers_ctx *ctx)
{
	size_t	min_pos;

	if (is_sorted(ctx->stack_a))
		return ;
	while (ctx->stack_a->top != (size_t)-1)
	{
		min_pos = find_min_position(ctx->stack_a);
		rotate_min_to_top(ctx, min_pos);
		push_b(ctx);
	}
	while (ctx->stack_b->top != (size_t)-1)
		push_a(ctx);
}
