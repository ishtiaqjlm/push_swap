/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   medium_sort.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/22 16:50:30 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/10/22 17:05:49 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>
#include <stdlib.h>
#include <stack.h>
#include <two_towers.h>

static size_t get_range_size(size_t n)
{
    size_t range;

    range = 1;
    while (range < n / range)
        range++;
    return (range);
}

static int normalize_ranks(t_array_stack *stack)
{
    size_t n;
    size_t i;
    size_t j;
    size_t rank;
    int *values;
    int *ranks;

    if (stack->top == (size_t)-1)
        return (0);
    n = stack->top + 1;
    values = malloc(sizeof(int) * n);
    ranks = malloc(sizeof(int) * n);
    if (!values || !ranks)
    {
        free(values);
        free(ranks);
        return (-1);
    }
    i = 0;
    while (i < n)
    {
        values[i] = stack->data[i];
        i++;
    }
    i = 0;
    while (i < n)
    {
        rank = 0;
        j = 0;
        while (j < n)
        {
            if (values[j] < values[i])
                rank++;
            j++;
        }
        ranks[i] = (int)rank;
        i++;
    }
    i = 0;
    while (i < n)
    {
        stack->data[i] = ranks[i];
        i++;
    }
    free(values);
    free(ranks);
    return (0);
}

static void push_range(t_two_towers_ctx *ctx, size_t low, size_t high)
{
    size_t i;
    size_t count;
    int rank;

    count = ctx->stack_a->top + 1;
    i = 0;
    while (i < count)
    {
        rank = ctx->stack_a->data[ctx->stack_a->top];
        if (rank >= (int)low && rank <= (int)high)
            push_b(ctx);
        else
            rotate_a(ctx);
        i++;
    }
}

static void partition_ranges(t_two_towers_ctx *ctx, size_t n)
{
    size_t low;
    size_t high;
    size_t range;

    low = 0;
    range = get_range_size(n);
    while (low < n)
    {
        high = low + range - 1;
        if (high >= n)
            high = n - 1;
        push_range(ctx, low, high);
        low = high + 1;
    }
}

void    sort_medium(t_two_towers_ctx *ctx)
{
    size_t n;

    if (ctx->stack_a->top == (size_t)-1)
        return ;
    n = ctx->stack_a->top + 1;
    if (n < 2)
        return ;
    if (normalize_ranks(ctx->stack_a) == -1)
        return ;
    partition_ranges(ctx, n);
}

