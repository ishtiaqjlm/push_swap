/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algorithms.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/14 13:27:21 by aazubel           #+#    #+#             */
/*   Updated: 2026/10/22 17:15:49 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ALGORITHMS_H
# define ALGORITHMS_H
# include "two_towers.h"

void	minmax_sort(int *v, size_t n);
void	shell_sort(int *v, size_t n);
void	heap_sort(int *v, size_t n);
void	adaptive_sort(int *v, size_t n);
void	sort_two(t_two_towers_ctx *ctx);
void	sort_three(t_two_towers_ctx *ctx);
void	sort_simple_general(t_two_towers_ctx *ctx);
void    sort_medium(t_two_towers_ctx *ctx);
#endif	// ALGORITHMS_H
